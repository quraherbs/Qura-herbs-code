import { type NextRequest, NextResponse } from "next/server"
import nodemailer from "nodemailer"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { orderId, customerEmail, customerName, orderItems, subtotal, shippingCharge, total } = body

    // Create transporter (you'll need to configure this with actual SMTP settings)
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || "smtp.gmail.com",
      port: Number.parseInt(process.env.SMTP_PORT || "587"),
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    })

    // Email to admin
    const adminEmailHtml = `
      <h2>New Order Received - #${orderId.slice(0, 8)}</h2>
      <p><strong>Customer:</strong> ${customerName}</p>
      <p><strong>Email:</strong> ${customerEmail}</p>
      
      <h3>Order Items:</h3>
      <ul>
        ${orderItems
          .map(
            (item: any) => `
          <li>${item.name} - Quantity: ${item.quantity} - ₹${item.price}</li>
        `,
          )
          .join("")}
      </ul>
      
      <p><strong>Subtotal:</strong> ₹${subtotal.toFixed(2)}</p>
      <p><strong>Shipping:</strong> ₹${shippingCharge.toFixed(2)}</p>
      <p><strong>Total:</strong> ₹${total.toFixed(2)}</p>
    `

    // Email to customer
    const customerEmailHtml = `
      <h2>Thank you for your order!</h2>
      <p>Dear ${customerName},</p>
      <p>Your order has been received and is being processed.</p>
      
      <h3>Order Details:</h3>
      <p><strong>Order ID:</strong> ${orderId.slice(0, 8)}</p>
      
      <h3>Items:</h3>
      <ul>
        ${orderItems
          .map(
            (item: any) => `
          <li>${item.name} - Quantity: ${item.quantity} - ₹${item.price}</li>
        `,
          )
          .join("")}
      </ul>
      
      <p><strong>Subtotal:</strong> ₹${subtotal.toFixed(2)}</p>
      <p><strong>Shipping:</strong> ₹${shippingCharge.toFixed(2)}</p>
      <p><strong>Total:</strong> ₹${total.toFixed(2)}</p>
      
      <p>Our team will reach out to you, and your order will be shipped once confirmed.</p>
      <p>Thank you for shopping with Qura Herbs!</p>
    `

    // Send email to admin
    await transporter.sendMail({
      from: process.env.SMTP_USER,
      to: "quraherbs@gmail.com",
      subject: `New Order - #${orderId.slice(0, 8)}`,
      html: adminEmailHtml,
    })

    // Send confirmation email to customer
    await transporter.sendMail({
      from: process.env.SMTP_USER,
      to: customerEmail,
      subject: "Order Confirmation - Qura Herbs",
      html: customerEmailHtml,
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Error sending email:", error)
    return NextResponse.json({ error: "Failed to send email" }, { status: 500 })
  }
}




// import { type NextRequest, NextResponse } from "next/server"
// import nodemailer from "nodemailer"

// export async function POST(request: NextRequest) {
//   try {
//     const body = await request.json()
//     const { orderId, customerEmail, customerName, orderItems, subtotal, shippingCharge, total } = body

//     // Create transporter
//     const transporter = nodemailer.createTransport({
//       host: process.env.SMTP_HOST || "smtp.gmail.com",
//       port: Number.parseInt(process.env.SMTP_PORT || "587"),
//       secure: false,
//       auth: {
//         user: process.env.SMTP_USER,
//         pass: process.env.SMTP_PASS,
//       },
//     })

//     // Helper to render items
//     const renderItems = (items: any[]) =>
//       items
//         .map(
//           (item) => `
//           <li>${item.name} — Qty: ${item.quantity} — ₹${item.price * item.quantity}</li>
//         `
//         )
//         .join("")

//     // ---------- ✉️ Admin Email ----------
//     const adminEmailHtml = `
//       <h2>🛍️ New Order Received — #${orderId.slice(0, 8)}</h2>
//       <p><strong>Customer:</strong> ${customerName}</p>
//       <p><strong>Email:</strong> ${customerEmail}</p>

//       <h3>Order Items:</h3>
//       <ul>${renderItems(orderItems)}</ul>

//       <p><strong>Subtotal:</strong> ₹${subtotal.toFixed(2)}</p>
//       <p><strong>Shipping:</strong> ₹${shippingCharge.toFixed(2)}</p>
//       <p><strong>Total:</strong> ₹${total.toFixed(2)}</p>

//       <hr/>
//       <p>Login to the admin dashboard to view full order details.</p>
//     `

//     // ---------- 🌿 Customer Email ----------
//     const customerEmailHtml = `
//       <h2>🌿 Your Order Has Been Confirmed!</h2>
//       <p>Hi ${customerName},</p>
//       <p>Thank you for shopping with <b>Qura Herbs</b>.</p>
//       <p>Your order <strong>#${orderId.slice(0, 8)}</strong> has been successfully placed.</p>

//       <h3>Order Details:</h3>
//       <ul>${renderItems(orderItems)}</ul>

//       <p><strong>Subtotal:</strong> ₹${subtotal.toFixed(2)}<br/>
//       <strong>Shipping:</strong> ₹${shippingCharge.toFixed(2)}<br/>
//       <strong>Total:</strong> ₹${total.toFixed(2)}</p>

//       <p>We’ll send another email once your order ships.</p>
//       <p>Thanks again for choosing Qura Herbs 💚</p>
//     `

//     // Send to admin
//     await transporter.sendMail({
//       from: `"Qura Herbs" <${process.env.SMTP_USER}>`,
//       to: "quraherbs@gmail.com", // Admin email
//       subject: `🛒 New Order Received — #${orderId.slice(0, 8)}`,
//       html: adminEmailHtml,
//     })

//     // Send to customer
//     await transporter.sendMail({
//       from: `"Qura Herbs" <${process.env.SMTP_USER}>`,
//       to: customerEmail,
//       subject: "✅ Your Order Has Been Confirmed — Qura Herbs",
//       html: customerEmailHtml,
//     })

//     return NextResponse.json({ success: true })
//   } catch (error) {
//     console.error("[Error sending email]:", error)
//     return NextResponse.json({ error: "Failed to send email" }, { status: 500 })
//   }
// }

// import { type NextRequest, NextResponse } from "next/server"
// import nodemailer from "nodemailer"

// export async function POST(request: NextRequest) {
//   try {
//     const body = await request.json()
//     const {
//       orderId,
//       customerEmail,
//       customerName,
//       orderItems,
//       subtotal,
//       shippingCharge,
//       total,
//     } = body

//     // --- Create transporter ---
//     const transporter = nodemailer.createTransport({
//       host: process.env.SMTP_HOST || "smtp.gmail.com",
//       port: Number.parseInt(process.env.SMTP_PORT || "587"),
//       secure: false,
//       auth: {
//         user: process.env.SMTP_USER,
//         pass: process.env.SMTP_PASS,
//       },
//     })

//     // --- Helper: render order items ---
//     const renderItems = (items: any[]) =>
//       items
//         .map(
//           (item) => `
//           <tr>
//             <td style="padding:8px 0;">${item.name}</td>
//             <td style="padding:8px 0; text-align:center;">${item.quantity}</td>
//             <td style="padding:8px 0; text-align:right;">₹${(
//               item.price * item.quantity
//             ).toFixed(2)}</td>
//           </tr>
//         `
//         )
//         .join("")

//     // --- Admin Email ---
//     const adminEmailHtml = `
//       <div style="background:#EEEAE1; color:#0A0A0A; padding:30px; font-family:Arial, sans-serif;">
//         <h2 style="margin-top:0;">🛍️ New Order Received — #${orderId.slice(
//           0,
//           8
//         )}</h2>
//         <p><strong>Customer:</strong> ${customerName}</p>
//         <p><strong>Email:</strong> ${customerEmail}</p>

//         <h3>Order Items:</h3>
//         <table style="width:100%; border-collapse:collapse;">
//           <thead>
//             <tr>
//               <th align="left">Product</th>
//               <th align="center">Qty</th>
//               <th align="right">Total</th>
//             </tr>
//           </thead>
//           <tbody>${renderItems(orderItems)}</tbody>
//         </table>

//         <hr style="border:none; border-top:1px solid #ccc; margin:20px 0;"/>

//         <p><strong>Subtotal:</strong> ₹${subtotal.toFixed(2)}</p>
//         <p><strong>Shipping:</strong> ₹${shippingCharge.toFixed(2)}</p>
//         <p><strong>Total:</strong> ₹${total.toFixed(2)}</p>

//         <p style="margin-top:20px;">Login to the admin dashboard to view full order details.</p>

//         <div style="text-align:center; margin-top:40px;">
//           <img 
//             src="cid:qura-logo"
//             alt="Qura Herbs" 
//             width="120" 
//             height="auto"
//             style="display:block; margin:0 auto 10px auto;"
//           />
//           <p style="color:#0A0A0A; font-size:12px; margin:0;">© 2025 Qura Herbs. All rights reserved.</p>
//         </div>
//       </div>
//     `

//     // --- Customer Email ---
//     const customerEmailHtml = `
//       <div style="background:#EEEAE1; color:#0A0A0A; padding:30px; font-family:Arial, sans-serif;">
//         <h2 style="margin-top:0;">🌿 Your Order Has Been Confirmed!</h2>
//         <p>Hi ${customerName},</p>
//         <p>Thank you for shopping with <strong>Qura Herbs</strong>.</p>
//         <p>Your order <strong>#${orderId.slice(
//           0,
//           8
//         )}</strong> has been successfully placed.</p>

//         <h3>Order Details:</h3>
//         <table style="width:100%; border-collapse:collapse;">
//           <thead>
//             <tr>
//               <th align="left">Product</th>
//               <th align="center">Qty</th>
//               <th align="right">Total</th>
//             </tr>
//           </thead>
//           <tbody>${renderItems(orderItems)}</tbody>
//         </table>

//         <hr style="border:none; border-top:1px solid #ccc; margin:20px 0;"/>

//         <p><strong>Subtotal:</strong> ₹${subtotal.toFixed(2)}<br/>
//         <strong>Shipping:</strong> ₹${shippingCharge.toFixed(2)}<br/>
//         <strong>Total:</strong> ₹${total.toFixed(2)}</p>

//         <p style="margin-top:20px;">We’ll send another email once your order ships.</p>
//         <p>Thanks again for choosing <strong>Qura Herbs</strong> 💚</p>

//         <div style="text-align:center; margin-top:40px;">
//           <img 
//             src="cid:qura-logo"
//             alt="Qura Herbs" 
//             width="120" 
//             height="auto"
//             style="display:block; margin:0 auto 10px auto;"
//           />
//           <p style="color:#0A0A0A; font-size:13px; margin:0;">Warm regards,<br/><strong>The Qura Herbs Team</strong></p>
//           <p style="color:#0A0A0A; font-size:12px; margin-top:8px;">📧 <a href="mailto:quraherbs@gmail.com" style="color:#0A0A0A;">quraherbs@gmail.com</a></p>
//           <p style="color:#0A0A0A; font-size:11px; margin-top:8px;">© 2025 Qura Herbs. All rights reserved.</p>
//         </div>
//       </div>
//     `

//     // --- Send Admin Email ---
//     await transporter.sendMail({
//       from: `"Qura Herbs" <${process.env.SMTP_USER}>`,
//       to: "quraherbs@gmail.com",
//       subject: `🛒 New Order Received — #${orderId.slice(0, 8)}`,
//       html: adminEmailHtml,
//       attachments: [
//         {
//           filename: "logo-footer.PNG",
//           path: "./public/logo-footer.PNG", // adjust if different
//           cid: "qura-logo",
//         },
//       ],
//     })

//     // --- Send Customer Email ---
//     await transporter.sendMail({
//       from: `"Qura Herbs" <${process.env.SMTP_USER}>`,
//       to: customerEmail,
//       subject: "✅ Your Order Has Been Confirmed — Qura Herbs",
//       html: customerEmailHtml,
//       attachments: [
//         {
//           filename: "logo-footer.PNG",
//           path: "./public/logo-footer.PNG",
//           cid: "qura-logo",
//         },
//       ],
//     })

//     return NextResponse.json({ success: true })
//   } catch (error) {
//     console.error("[Error sending email]:", error)
//     return NextResponse.json({ error: "Failed to send email" }, { status: 500 })
//   }
// }
