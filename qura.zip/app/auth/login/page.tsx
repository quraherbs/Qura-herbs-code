// import { Header } from "@/components/header"
// import { Footer } from "@/components/footer"
// import { LoginForm } from "@/components/login-form"

// export default function LoginPage() {
//   return (
//     <div className="flex flex-col min-h-screen">
//       <Header />
//       <main className="flex-1 flex items-center justify-center py-12 bg-[#f0e9e2]">
//         <LoginForm />
//       </main>
//       <Footer />
//     </div>
//   )
// }
import { Suspense } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { LoginForm } from "@/components/login-form"

export default function LoginPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1 flex items-center justify-center py-12 bg-[#f0e9e2]">
        <Suspense fallback={<div>Loading...</div>}>
          <LoginForm />
        </Suspense>
      </main>
      <Footer />
    </div>
  )
}
