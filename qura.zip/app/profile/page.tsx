// import { redirect } from "next/navigation"
// import { Header } from "@/components/header"
// import { Footer } from "@/components/footer"
// import { createClient } from "@/lib/supabase/server"
// import { ProfileClient } from "@/components/profile-client"

// export default async function ProfilePage() {
//   const supabase = await createClient()

//   const {
//     data: { user },
//   } = await supabase.auth.getUser()

//   if (!user) {
//     redirect("/auth/login")
//   }

//   const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

//   return (
//     <div className="flex flex-col min-h-screen">
//       <Header />
//       <main className="flex-1 py-12 bg-[#ffffff]">
//         <ProfileClient profile={profile} userEmail={user.email || ""} />
//       </main>
//       <Footer />
//     </div>
//   )
// }

import { redirect } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { createClient } from "@/lib/supabase/server"
import { ProfileClient } from "@/components/profile-client"

export default async function ProfilePage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  return (
    <div className="flex flex-col min-h-screen bg-[#EEEAE1] text-[#0A0A0A]">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="flex-grow pt-28 md:pt-32 pb-20">
        <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Title */}
          {/* <div className="text-center mb-12 md:mb-16">
            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#0A0A0A]">
              My Profile
            </h1>
            <p className="mt-3 text-[11px] sm:text-xs tracking-[0.25em] text-[#3C4433] uppercase">
              Manage your account and preferences
            </p>
          </div> */}

          {/* Profile Client */}
          <div className="bg-[#F6F4ED] border border-[#3C4433]/15 rounded-none shadow-[0_3px_10px_rgba(0,0,0,0.03)] p-6 sm:p-8 md:p-10">
            <ProfileClient profile={profile} userEmail={user.email || ""} />
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  )
}
