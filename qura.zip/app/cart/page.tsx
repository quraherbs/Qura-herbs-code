// import { redirect } from "next/navigation"
// import { Header } from "@/components/header"
// import { Footer } from "@/components/footer"
// import { createClient } from "@/lib/supabase/server"
// import { CartClient } from "@/components/cart-client"

// export default async function CartPage() {
//   const supabase = await createClient()

//   const {
//     data: { user },
//   } = await supabase.auth.getUser()

//   if (!user) {
//     redirect("/auth/login")
//   }

//   // Fetch cart items with product details
//   const { data: cartItems } = await supabase
//     .from("cart")
//     .select(`
//       *,
//       products (*)
//     `)
//     .eq("user_id", user.id)
//     .order("created_at", { ascending: false })

//   // Fetch user profile for checkout
//   const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

//   return (
//     <div className="flex flex-col min-h-screen">
//       <Header />
//       <main className="flex-1 py-12 bg-[#ffffff]">
//         <CartClient initialCartItems={cartItems || []} userProfile={profile} />
//       </main>
//       <Footer />
//     </div>
//   )
// }
import { redirect } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { createClient } from "@/lib/supabase/server"
import { CartClient } from "@/components/cart-client"

export default async function CartPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Fetch cart items with product details
  const { data: cartItems } = await supabase
    .from("cart")
    .select(`
      *,
      products (*)
    `)
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  // Fetch user profile for checkout
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1 py-12 bg-[#EEEAE1]">
        <CartClient initialCartItems={cartItems || []} userProfile={profile} />
      </main>
      <Footer />
    </div>
  )
}
