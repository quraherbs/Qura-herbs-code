// import { Header } from "@/components/header"
// import { Footer } from "@/components/footer"
// import { createClient } from "@/lib/supabase/server"
// import  HeroSection from "@/components/home/hero-section"
// import Greetings from "@/components/home/cta"
// import BestSellingProducts from "@/components/home/bestselling"
// import Benefits from "@/components/home/benefits-section"
// import MeetTheQuraHerbs from "@/components/home/allproducts"

// export default async function HomePage() {
//   const supabase = await createClient()

//   const { data: products } = await supabase
//     .from("products")
//     .select("*")
//     .eq("is_active", true)
//     .limit(6)

//   return (
//     <div className="relative flex flex-col min-h-screen bg-[#EEEAE1] text-gray-900">
//       {/* Header */}
//       <Header />

//       {/* Main Content */}
//       <main className="flex-grow pt-20 pb-24">
//         {/* 👆 Added top and bottom padding so content never overlaps header/footer */}
//         <HeroSection />
//         <BestSellingProducts products={products || []} />
//         <Benefits />
//         <Greetings />
//         {/* <MeetTheQuraHerbs /> */}
//       </main>

//       {/* Footer */}
//       <Footer />
//     </div>
//   )
// }
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { createClient } from "@/lib/supabase/server"
import HeroSection from "@/components/home/hero-section"
import Greetings from "@/components/home/cta"
import BestSellingProducts from "@/components/home/bestselling"
import Benefits from "@/components/home/benefits-section"
import MeetTheQuraHerbs from "@/components/home/allproducts"

export default async function HomePage() {
  const supabase = await createClient()

  const { data: products } = await supabase
    .from("products")
    .select("*")
    .eq("is_active", true)
    .limit(6)

  return (
    <div className="relative flex flex-col min-h-screen bg-[#EEEAE1] text-gray-900">
      {/* Header Overlay */}
      <div className="absolute top-0 left-0 w-full z-30">
        <Header />
      </div>

      {/* Main Content */}
      <main className="flex-grow">
        <HeroSection />
        <BestSellingProducts products={products || []} />
        <Benefits />
        <Greetings />
      </main>

      <Footer />
    </div>
  )
}
