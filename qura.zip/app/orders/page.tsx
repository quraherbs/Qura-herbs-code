// import { redirect } from "next/navigation"
// import { Header } from "@/components/header"
// import { Footer } from "@/components/footer"
// import { createClient } from "@/lib/supabase/server"
// import { OrdersList } from "@/components/orders-list"

// export default async function OrdersPage() {
//   const supabase = await createClient()

//   const {
//     data: { user },
//   } = await supabase.auth.getUser()

//   if (!user) {
//     redirect("/auth/login")
//   }

//   const { data: orders } = await supabase
//     .from("orders")
//     .select(`
//       *,
//       order_items (*)
//     `)
//     .eq("user_id", user.id)
//     .order("created_at", { ascending: false })

//   return (
//     <div className="flex flex-col min-h-screen">
//       <Header />
//       <main className="flex-1 py-12 bg-[#ffffff]">
//         <div className="container mx-auto px-4">
//           <h1 className="text-3xl md:text-4xl font-bold text-[#000000] mb-8">My Orders</h1>
//           <OrdersList orders={orders || []} />
//         </div>
//       </main>
//       <Footer />
//     </div>
//   )
// }
import { redirect } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { createClient } from "@/lib/supabase/server"

export default async function OrdersPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: orders } = await supabase
    .from("orders")
    .select(`
      *,
      order_items (*)
    `)
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="flex flex-col min-h-screen bg-[#EEEAE1] text-[#0A0A0A]">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="flex-grow pt-28 md:pt-32 pb-20">
        <div className="max-w-5xl mx-auto w-full px-4 sm:px-6 lg:px-8">
          {/* Title */}
          <div className="text-center mb-12 md:mb-16">
            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#0A0A0A]">
              My Orders
            </h1>
            <p className="mt-3 text-[11px] sm:text-xs tracking-[0.25em] text-[#3C4433] uppercase">
              Your recent skincare purchases
            </p>
          </div>

          <OrdersList orders={orders || []} />
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  )
}

// 🧾 Inline OrdersList Component
function OrdersList({ orders }: { orders: any[] }) {
  if (!orders.length) {
    return (
      <div className="text-center text-[#0A0A0A]/60 text-base md:text-lg mt-10 font-light">
        You have no orders yet.
      </div>
    )
  }

  const getStatusStyle = (status: string) => {
    switch (status?.toLowerCase()) {
      case "pending":
        return "bg-[#FFF8E1] text-[#A67C00]"
      case "shipped":
        return "bg-[#E3F2FD] text-[#1565C0]"
      case "delivered":
        return "bg-[#E8F5E9] text-[#2E7D32]"
      case "cancelled":
        return "bg-[#FFEBEE] text-[#C62828]"
      default:
        return "bg-[#F3F4F6] text-[#3C4433]"
    }
  }

  return (
    <div className="space-y-8">
      {orders.map((order) => {
        const shipping = 80
        const subtotal = order.subtotal || 0
        const total = subtotal + shipping

        return (
          <div
            key={order.id}
            className="bg-[#F6F4ED] border border-[#3C4433]/15 rounded-2xl shadow-[0_3px_10px_rgba(0,0,0,0.03)] p-6 hover:shadow-[0_6px_20px_rgba(0,0,0,0.06)] transition-all duration-300"
          >
            {/* Order Header */}
            <div className="flex justify-between items-center mb-2">
              <h2 className="font-medium text-lg md:text-xl text-[#0A0A0A] tracking-tight">
                Order #{order.id.slice(0, 8)}
              </h2>
              <span
                className={`text-xs font-medium px-3 py-1.5 rounded-full ${getStatusStyle(
                  order.status
                )}`}
              >
                {order.status}
              </span>
            </div>

            {/* Order Date */}
            <p className="text-xs md:text-sm text-[#0A0A0A]/60 mb-4">
              {new Date(order.created_at).toLocaleDateString("en-IN", {
                day: "2-digit",
                month: "long",
                year: "numeric",
              })}
            </p>

            {/* Order Items */}
            <div className="divide-y divide-[#3C4433]/10 mb-4">
              {order.order_items?.map((item: any) => (
                <div
                  key={item.id}
                  className="flex justify-between py-2 text-[#0A0A0A] text-sm"
                >
                  <span>{item.product_name}</span>
                  <span>× {item.quantity}</span>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="border-t border-[#3C4433]/10 pt-4 text-sm space-y-1">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping</span>
                <span>₹{shipping.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-medium text-[#0A0A0A] pt-2">
                <span>Total</span>
                <span>₹{total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
