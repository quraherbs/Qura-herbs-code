"use client"

import Image from "next/image"
import { Footer } from "@/components/footer"
import { Header } from "@/components/header"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-[#EEEAE1] text-[#0A0A0A]">
      <Header />

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 lg:px-0 py-16 lg:py-24 pt-32">
        <div className="flex flex-col items-start space-y-10">

          {/* Content */}
          <div className="space-y-6">
            <h1 className="text-3xl lg:text-4xl font-serif font-semibold leading-tight text-[#0A0A0A]">
              Our Little Journey!
            </h1>

            <p className="text-sm leading-relaxed text-[#0A0A0A]/80 font-sans">
              At Qura Herbs, we believe beauty isn't about fairness — it's about confidence, health, and authenticity.
              Our story began from a personal struggle with color-based judgment, inspiring us to redefine beauty through
              acceptance and natural care.
            </p>

            <div className="space-y-4 text-[#0A0A0A]/80 font-sans">
              <p className="text-sm leading-relaxed">
                What began as a simple experiment with herbal remedies blossomed into a purpose we now hold close to our hearts. 
                Through countless trials and real transformations, we realized the world deserved to experience this change too.
              </p>

              <p className="text-sm leading-relaxed">
                <strong className="font-medium">On January 13, 2025</strong>, in Coimbatore, Tamil Nadu, Qura Herbs was born — not just as a brand,
                but as a movement to celebrate natural beauty and self-acceptance.
              </p>

              <p className="text-sm leading-relaxed">
                We're proud to see our customers glow from within. If even one person gains confidence through our products,
                that alone makes our journey worth it.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Section */}
      <section className="max-w-7xl mx-auto px-6 lg:px-0 pb-16 lg:pb-24">
        <h2 className="text-2xl font-serif font-semibold mb-16 text-[#0A0A0A] text-center">
          Our Leadership
        </h2>

        {/* MOBILE → 1x2 (stacked) | DESKTOP → 2 columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-3xl mx-auto">

          {/* Founder */}
          <div className="flex flex-col items-center">
            <div className="relative w-full max-w-xs aspect-[3/4] bg-[#EEEAE1]">
              <Image
                src="/about/founder-2.webp"
                alt="Founder of Qura Herbs"
                fill
                className="object-contain w-full h-full"
              />
            </div>

            <div className="mt-4 text-center">
              <p className="text-base font-semibold text-[#0A0A0A]">Nandavel V</p>
              <p className="text-sm text-[#0A0A0A]/70">Founder</p>
            </div>
          </div>

          {/* CEO */}
          <div className="flex flex-col items-center">
            <div className="relative w-full max-w-xs aspect-[3/4] bg-[#EEEAE1]">
              <Image
                src="/about/ceo.JPG"
                alt="CEO of Qura Herbs"
                fill
                className="object-contain w-full h-full"
              />
            </div>

            <div className="mt-4 text-center">
              <p className="text-base font-semibold text-[#0A0A0A]">Pranavi</p>
              <p className="text-sm text-[#0A0A0A]/70">CEO</p>
            </div>
          </div>

        </div>
      </section>
    </div>
  )
}
