// "use client"

// import { Header } from "@/components/header"
// import { Footer } from "@/components/footer"
// import { ProductCard } from "@/components/product-card"
// import { useEffect, useState } from "react"
// import { createClient } from "@/lib/supabase/client"
// import type { Product } from "@/lib/types"
// import { motion } from "framer-motion"

// export default function ProductsPage() {
//   const [products, setProducts] = useState<Product[]>([])
//   const [loading, setLoading] = useState(true)

//   useEffect(() => {
//     const supabase = createClient()

//     supabase
//       .from("products")
//       .select("*")
//       .eq("is_active", true)
//       .order("created_at", { ascending: false })
//       .then(({ data }) => {
//         setProducts(data || [])
//         setLoading(false)
//       })
//   }, [])

//   return (
//     <div className="flex flex-col min-h-screen">
//       <Header />
//       <main className="flex-1 py-12 bg-[#ffffff]">
//         <div className="container mx-auto px-4">
//           <motion.div
//             className="mb-12"
//             initial={{ opacity: 0, y: 20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.6 }}
//           >
//             <h1 className="text-4xl md:text-5xl font-bold text-[#000000] mb-4 text-balance font-serif">Our Products</h1>
//             <p className="text-lg text-[#000000]/70 max-w-2xl">
//               Explore our complete range of natural skincare and wellness products
//             </p>
//           </motion.div>

//           <motion.div
//             className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
//             initial="hidden"
//             animate="visible"
//             variants={{
//               visible: {
//                 transition: {
//                   staggerChildren: 0.1,
//                 },
//               },
//             }}
//           >
//             {products?.map((product: Product) => (
//               <motion.div
//                 key={product.id}
//                 variants={{
//                   hidden: { opacity: 0, y: 20 },
//                   visible: { opacity: 1, y: 0 },
//                 }}
//                 transition={{ duration: 0.5 }}
//               >
//                 <ProductCard product={product} />
//               </motion.div>
//             ))}
//           </motion.div>

//           {!loading && products.length === 0 && (
//             <div className="text-center py-12">
//               <p className="text-[#000000]/70">No products available at the moment.</p>
//             </div>
//           )}
//         </div>
//       </main>
//       <Footer />
//     </div>
//   )
// }

"use client";

import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { Product } from "@/lib/types";
import Link from "next/link";

// Price formatter for Indian Rupees
const formatPrice = (value: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(value);

// ProductCard Component
function ProductCard({ product }: { product: Product }) {
  const discount = (product as any).discount_percentage as number | undefined;
  const hasDiscount = discount !== undefined && discount > 0;
  const discountedPrice = hasDiscount
    ? product.price * (1 - discount / 100)
    : product.price;

  return (
    <Link href={`/products/${product.id}`} className="block">
      <div className="w-full">
        {/* Image Container - Fixed aspect ratio */}
        <div className="relative w-full aspect-[3/4] bg-[#C9C5BA] overflow-hidden mb-4">
          <img
            src={product.image_url ?? "/images/placeholder.png"}
            alt={product.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />

          {/* Discount Badge */}
          {hasDiscount && (
            <div className="absolute top-3 left-3 bg-white rounded-full px-3 py-1">
              <span className="text-[10px] font-medium text-[#0A0A0A] tracking-wider">
                {discount}% OFF
              </span>
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="text-center">
          <h3 className="font-serif text-sm md:text-base text-[#0A0A0A] mb-1">
            {product.name}
          </h3>

          {/* Price */}
          <div className="flex items-center justify-center gap-2">
            {hasDiscount ? (
              <>
                <span className="text-xs md:text-sm text-[#0A0A0A] font-medium">
                  {formatPrice(discountedPrice)}
                </span>
                <span className="text-xs text-[#0A0A0A]/50 line-through">
                  {formatPrice(product.price)}
                </span>
              </>
            ) : (
              <span className="text-xs md:text-sm text-[#0A0A0A] font-medium">
                {formatPrice(product.price)}
              </span>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}

// Simple loading skeletons
function LoadingSkeleton() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-4 md:gap-x-6 lg:gap-x-8 gap-y-6 md:gap-y-8 animate-pulse">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="w-full">
          <div className="w-full aspect-[3/4] bg-[#D5D2C7] mb-4 rounded-md" />
          <div className="h-4 bg-[#D5D2C7] w-3/4 mx-auto mb-2 rounded" />
          <div className="h-3 bg-[#D5D2C7] w-1/2 mx-auto rounded" />
        </div>
      ))}
    </div>
  );
}

// Main Products Page Component
export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const supabase = createClient();

    supabase
      .from("products")
      .select("*")
      .eq("is_active", true)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setProducts(data || []);
        setLoading(false);
      });
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-[#EEEAE1] text-[#0A0A0A] font-sans">
      <Header />

      {/* Main Section */}
      <main className="flex-1 pt-28 md:pt-32 pb-16 md:pb-20">
        <div className="w-full max-w-7xl mx-auto px-4 md:px-8">
          {/* Section Header */}
          <div className="text-center mb-12 md:mb-16">
            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#0A0A0A]">
              Our Products
            </h1>
            <p className="mt-3 text-[11px] sm:text-xs tracking-[0.25em] text-[#3C4433] uppercase">
              Explore our full range of botanical skincare
            </p>
          </div>

          {/* Product Grid */}
          {loading ? (
            <LoadingSkeleton />
          ) : products.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-4 md:gap-x-6 lg:gap-x-8 gap-y-6 md:gap-y-8">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-[#0A0A0A]/70 text-sm md:text-base">
                No products available at the moment.
              </p>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
  