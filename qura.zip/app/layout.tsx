// import type React from "react"
// import type { Metadata } from "next"
// import { Playfair_Display, Inter } from "next/font/google"
// import { Analytics } from "@vercel/analytics/next"
// import { Suspense } from "react"
// import "./globals.css"

// const playfair = Playfair_Display({
//   subsets: ["latin"],
//   weight: ["400", "500", "600", "700"],
//   variable: "--font-playfair",
//   display: "swap",
// })

// const inter = Inter({
//   subsets: ["latin"],
//   variable: "--font-inter",
//   display: "swap",
// })

// export const metadata: Metadata = {
//   title: "Qura Herbs - Natural Skincare & Wellness",
//   description: "Premium natural skincare products crafted with traditional Indian herbs",
// }
// // 
// export default function RootLayout({
//   children,
// }: Readonly<{ children: React.ReactNode }>) {
//   return (
//     <html lang="en">
//       {/* 👇 Inter is default (font-sans) */}
//       <body className={`${inter.variable} ${playfair.variable} font-sans antialiased`}>
//         <Suspense fallback={<div>Loading...</div>}>{children}</Suspense>
//         <Analytics />
//       </body>
//     </html>
//   )
// }
// import type React from "react"
// import type { Metadata } from "next"
// import { Playfair_Display, Inter } from "next/font/google"
// import { Analytics } from "@vercel/analytics/next"
// import "./globals.css"

// const playfair = Playfair_Display({
//   subsets: ["latin"],
//   weight: ["400", "500", "600", "700"],
//   variable: "--font-playfair",
//   display: "swap",
// })

// const inter = Inter({
//   subsets: ["latin"],
//   variable: "--font-inter",
//   display: "swap",
// })

// export const metadata: Metadata = {
//   title: "Qura Herbs - Natural Skincare & Wellness",
//   description: "Premium natural skincare products crafted with traditional Indian herbs",
// }

// export default function RootLayout({
//   children,
// }: Readonly<{ children: React.ReactNode }>) {
//   return (
//     <html lang="en">
//       <body className={`${inter.variable} ${playfair.variable} font-sans antialiased`}>
//         {children}
//         <Analytics />
//       </body>
//     </html>
//   )
// }

import type React from "react";
import type { Metadata } from "next";
import { Playfair_Display, Inter } from "next/font/google";
import { Analytics } from "@vercel/analytics/next";
import "./globals.css";
import { SpeedInsights } from '@vercel/speed-insights/next';

const playfair = Playfair_Display({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-playfair",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Qura Herbs - Natural Skincare & Wellness",
  description:
    "Premium natural skincare and wellness products crafted with authentic Indian herbs. Explore nature’s power through Qura Herbs – where tradition meets purity.",
  keywords: [
    "Qura Herbs",
    "natural skincare",
    "organic beauty",
    "herbal wellness",
    "ayurvedic products",
    "Indian herbs",
    "eco-friendly skincare",
  ],
  authors: [{ name: "Qura Herbs" }],
  metadataBase: new URL("https://quraherbs.in"),
  openGraph: {
    title: "Qura Herbs - Natural Skincare & Wellness",
    description:
      "Premium natural skincare and wellness products crafted with authentic Indian herbs.",
    url: "https://quraherbs.in",
    siteName: "Qura Herbs",
    images: [
      {
        url: "/fav/android-chrome-512x512.png",
        width: 512,
        height: 512,
        alt: "Qura Herbs Logo",
      },
    ],
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Qura Herbs - Natural Skincare & Wellness",
    description:
      "Premium natural skincare and wellness products crafted with authentic Indian herbs.",
    images: ["/fav/android-chrome-512x512.png"],
    creator: "@quraherbs",
  },
  icons: {
    icon: [
      { url: "/fav/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/fav/favicon-16x16.png", sizes: "16x16", type: "image/png" },
    ],
    apple: { url: "/fav/apple-touch-icon.png" },
    shortcut: "/fav/favicon.ico",
  },
  manifest: "/fav/site.webmanifest",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body
        className={`${inter.variable} ${playfair.variable} font-sans antialiased`}
      >
        {children}
        <Analytics />
        <SpeedInsights />
      </body>
    </html>
  );
}
