import { redirect } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { createClient } from "@/lib/supabase/server"
import { AdminDashboard } from "@/components/admin-dashboard"

export default async function AdminPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user || user.email !== "quraherbs@gmail.com") {
    redirect("/")
  }

  // Fetch dashboard stats
  const { count: totalOrders } = await supabase.from("orders").select("*", { count: "exact", head: true })

  const { count: totalProducts } = await supabase.from("products").select("*", { count: "exact", head: true })

  const { data: recentOrders } = await supabase
    .from("orders")
    .select(`
      *,
      order_items (*)
    `)
    .order("created_at", { ascending: false })
    .limit(10)

  const { data: revenue } = await supabase.from("orders").select("total")

  const totalRevenue = revenue?.reduce((sum, order) => sum + order.total, 0) || 0

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1 py-12 bg-[#ffffff]">
        <AdminDashboard
          totalOrders={totalOrders || 0}
          totalProducts={totalProducts || 0}
          totalRevenue={totalRevenue}
          recentOrders={recentOrders || []}
        />
      </main>
      <Footer />
    </div>
  )
}
