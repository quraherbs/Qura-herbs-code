# 🌿 Qura Herbs - Ayurvedic Skincare E-commerce

A modern, elegant e-commerce platform for Qura Herbs, featuring a beautiful "Tan Pearl" aesthetic with smooth animations and a complete admin dashboard.

## ✨ Features

- 🛍️ **Product Catalog** - Browse and search Ayurvedic skincare products
- 🛒 **Shopping Cart** - Real-time cart sync with Supabase
- 👤 **User Authentication** - Secure login/signup with Supabase Auth
- 📦 **Order Management** - Place orders with email notifications
- 🎨 **Admin Dashboard** - Manage products and orders
- 📱 **Responsive Design** - Mobile-first, works on all devices
- ✉️ **Email Notifications** - Automated order confirmations via Nodemailer
- 🎭 **Smooth Animations** - Buttery smooth Framer Motion animations

## 🚀 Tech Stack

- **Framework:** Next.js 15 (App Router)
- **Styling:** Tailwind CSS v4
- **Database:** Supabase (PostgreSQL)
- **Authentication:** Supabase Auth
- **Animations:** Framer Motion
- **Email:** Nodemailer
- **UI Components:** shadcn/ui
- **Deployment:** Vercel

## 📋 Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** 18.x or higher
- **npm** or **pnpm** (recommended)
- A **Supabase** account (free tier works)
- An **SMTP** email service (Gmail, SendGrid, etc.)

## 🛠️ Local Setup

### 1. Clone the Repository

\`\`\`bash
git clone <your-repo-url>
cd qura-herbs-ecommerce
\`\`\`

### 2. Install Dependencies

\`\`\`bash
npm install
# or
pnpm install
\`\`\`

### 3. Set Up Supabase

1. Create a new project at [supabase.com](https://supabase.com)
2. Copy your project URL and anon key from Settings > API

### 4. Configure Environment Variables

Create a `.env.local` file in the root directory:

\`\`\`env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key

# Email (SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

# Supabase Redirect (for development)
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000
\`\`\`

**Note for Gmail users:** You need to generate an [App Password](https://support.google.com/accounts/answer/185833) instead of using your regular password.

### 5. Set Up Database

Run the SQL scripts in order from the `scripts` folder in your Supabase SQL Editor:

1. `001_create_tables.sql` - Creates all database tables
2. `002_create_profile_trigger.sql` - Sets up auto-profile creation
3. `003_seed_products.sql` - Adds sample products
4. `004_create_admin_user.sql` - Creates admin user trigger

**Or** use the Supabase CLI:

\`\`\`bash
# Install Supabase CLI
npm install -g supabase

# Link to your project
supabase link --project-ref your_project_ref

# Run migrations
supabase db push
\`\`\`

### 6. Run Development Server

\`\`\`bash
npm run dev
# or
pnpm dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) in your browser.

## 👨‍💼 Admin Access

The admin dashboard is automatically accessible to the email: **admin@quraherbs.com**

To set up admin access:

1. Sign up with the email `admin@quraherbs.com`
2. Verify your email through Supabase
3. Access the admin dashboard at `/admin`

The admin can:
- ✅ Add, edit, and delete products
- ✅ View and manage all orders
- ✅ Update order statuses
- ✅ Upload product images

## 📁 Project Structure

\`\`\`
qura-herbs-ecommerce/
├── app/                      # Next.js app directory
│   ├── admin/               # Admin dashboard pages
│   ├── auth/                # Authentication pages
│   ├── cart/                # Shopping cart
│   ├── products/            # Product pages
│   ├── profile/             # User profile
│   └── orders/              # Order history
├── components/              # React components
│   ├── ui/                  # shadcn/ui components
│   ├── home/                # Home page sections
│   └── ...                  # Other components
├── lib/                     # Utilities
│   ├── supabase/           # Supabase clients
│   └── types.ts            # TypeScript types
├── scripts/                 # Database SQL scripts
└── public/                  # Static assets
\`\`\`

## 🎨 Design System

**Colors:**
- Tan: `#ccbcaa`
- Cream: `#f0e9e2`
- White: `#ffffff`
- Black: `#000000`

**Typography:**
- Headings: Cormorant Garamond (elegant serif)
- Body: Inter (clean sans-serif)

## 📧 Email Configuration

Order confirmation emails are sent to:
- **Customer:** Their registered email
- **Admin:** quraherbs@gmail.com

Configure SMTP settings in `.env.local` to enable email notifications.

## 🚢 Deployment

### Deploy to Vercel

1. Push your code to GitHub
2. Import project in [Vercel](https://vercel.com)
3. Add environment variables in Vercel dashboard
4. Deploy!

Vercel will automatically detect Next.js and configure the build settings.

## 🔒 Security Notes

- Row Level Security (RLS) is enabled on all Supabase tables
- Admin routes are protected by middleware
- User data is encrypted and secure
- Environment variables are never exposed to the client

## 🐛 Troubleshooting

**Issue:** Email not sending
- Check SMTP credentials in `.env.local`
- For Gmail, ensure you're using an App Password
- Check Vercel logs for error messages

**Issue:** Database connection failed
- Verify Supabase URL and keys
- Check if database tables are created
- Ensure RLS policies are set up correctly

**Issue:** Admin dashboard not accessible
- Sign up with `quraherbs@gmail.com\.com`
- Verify email in Supabase Auth dashboard
- Check middleware configuration

## 📝 License

This project is private and proprietary.

## 🤝 Support

For issues or questions, contact: quraherbs@gmail.com

---

Built with ❤️ using Next.js and Supabase
