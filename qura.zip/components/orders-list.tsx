"use client"

import { Card, CardContent } from "@/components/ui/card"
import type { Order, OrderItem } from "@/lib/types"
import { Package } from "lucide-react"

interface OrderWithItems extends Order {
  order_items: OrderItem[]
}

interface OrdersListProps {
  orders: OrderWithItems[]
}

export function OrdersList({ orders }: OrdersListProps) {
  if (orders.length === 0) {
    return (
      <div className="text-center py-16">
        <Package className="h-24 w-24 mx-auto text-[#ccbcaa] mb-6" />
        <h2 className="text-2xl font-bold text-[#000000] mb-4">No orders yet</h2>
        <p className="text-[#000000]/70">Your order history will appear here once you make a purchase</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {orders.map((order) => (
        <Card key={order.id} className="border-[#ccbcaa]/20">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
              <div>
                <h3 className="font-semibold text-[#000000] mb-1">Order #{order.id.slice(0, 8)}</h3>
                <p className="text-sm text-[#000000]/70">
                  {new Date(order.created_at).toLocaleDateString("en-IN", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>
              <div className="mt-2 md:mt-0">
                <span className="inline-block px-3 py-1 rounded-full text-sm font-medium bg-[#f0e9e2] text-[#000000]">
                  {order.status}
                </span>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              {order.order_items.map((item) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <span className="text-[#000000]/70">
                    {item.product_name} × {item.quantity}
                  </span>
                  <span className="text-[#000000]">₹{(item.product_price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>

            <div className="border-t border-[#ccbcaa]/20 pt-4">
              <div className="flex justify-between text-sm mb-1">
                <span className="text-[#000000]/70">Subtotal</span>
                <span className="text-[#000000]">₹{order.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-[#000000]/70">Shipping</span>
                <span className="text-[#000000]">₹{order.shipping_charge.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-[#000000]">
                <span>Total</span>
                <span>₹{order.total.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
