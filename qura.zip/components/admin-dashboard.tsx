"use client"

import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Order, OrderItem } from "@/lib/types"
import { Package, ShoppingBag, DollarSign, Plus } from "lucide-react"

interface OrderWithItems extends Order {
  order_items: OrderItem[]
}

interface AdminDashboardProps {
  totalOrders: number
  totalProducts: number
  totalRevenue: number
  recentOrders: OrderWithItems[]
}

export function AdminDashboard({ totalOrders, totalProducts, totalRevenue, recentOrders }: AdminDashboardProps) {
  return (
    <div className="container mx-auto px-4">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-[#000000]">Admin Dashboard</h1>
        <Link href="/admin/products/new">
          <Button className="bg-[#000000] text-[#ffffff] hover:bg-[#ccbcaa] hover:text-[#000000]">
            <Plus className="mr-2 h-4 w-4" />
            Add Product
          </Button>
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="border-[#ccbcaa]/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-[#000000]/70">Total Orders</CardTitle>
            <Package className="h-4 w-4 text-[#ccbcaa]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#000000]">{totalOrders}</div>
          </CardContent>
        </Card>

        <Card className="border-[#ccbcaa]/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-[#000000]/70">Total Products</CardTitle>
            <ShoppingBag className="h-4 w-4 text-[#ccbcaa]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#000000]">{totalProducts}</div>
          </CardContent>
        </Card>

        <Card className="border-[#ccbcaa]/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-[#000000]/70">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-[#ccbcaa]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#000000]">₹{totalRevenue.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Link href="/admin/products">
          <Card className="border-[#ccbcaa]/20 hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-[#000000] mb-2">Manage Products</h3>
              <p className="text-[#000000]/70">Add, edit, or remove products from your store</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/admin/orders">
          <Card className="border-[#ccbcaa]/20 hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-[#000000] mb-2">Manage Orders</h3>
              <p className="text-[#000000]/70">View and update order statuses</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Recent Orders */}
      <Card className="border-[#ccbcaa]/20">
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
        </CardHeader>
        <CardContent>
          {recentOrders.length === 0 ? (
            <p className="text-[#000000]/70 text-center py-8">No orders yet</p>
          ) : (
            <div className="space-y-4">
              {recentOrders.map((order) => (
                <div
                  key={order.id}
                  className="flex items-center justify-between p-4 border border-[#ccbcaa]/20 rounded-lg"
                >
                  <div>
                    <p className="font-semibold text-[#000000]">Order #{order.id.slice(0, 8)}</p>
                    <p className="text-sm text-[#000000]/70">{order.full_name}</p>
                    <p className="text-sm text-[#000000]/70">
                      {new Date(order.created_at).toLocaleDateString("en-IN")}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-[#000000]">₹{order.total.toFixed(2)}</p>
                    <span className="inline-block px-2 py-1 rounded-full text-xs font-medium bg-[#f0e9e2] text-[#000000]">
                      {order.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
