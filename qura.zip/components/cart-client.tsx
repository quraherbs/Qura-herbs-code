"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import type { CartItem, Profile } from "@/lib/types"
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { CheckoutModal } from "@/components/checkout-modal"
import { motion } from "framer-motion"

interface CartClientProps {
  initialCartItems: CartItem[]
  userProfile: Profile | null
}

export function CartClient({ initialCartItems, userProfile }: CartClientProps) {
  const [cartItems, setCartItems] = useState<CartItem[]>(initialCartItems)
  const [isLoading, setIsLoading] = useState(false)
  const [showCheckout, setShowCheckout] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClient()

  // ✅ FETCH CART ON MOUNT (Debug Mode)
  useEffect(() => {
    const fetchCart = async () => {
      console.log("🔄 Fetching cart data...")

      // 1️⃣ Check Auth
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser()

      if (userError) {
        console.error("❌ Auth error:", userError)
        return
      }

      if (!user) {
        console.warn("⚠️ No user found — probably not logged in.")
        return
      }

      console.log("✅ Logged in user:", user.id)

      // 2️⃣ Fetch Cart Items
      const { data, error } = await supabase
        .from("cart")
        .select(`*, products (*)`)
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("❌ Error fetching cart:", error)
      } else {
        console.log("🛒 Cart data fetched:", data)
        setCartItems(data || [])
      }
    }

    fetchCart()
  }, [supabase])

  // ✅ REALTIME SUBSCRIPTION
  useEffect(() => {
    const channel = supabase
      .channel("cart-changes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "cart" },
        async () => {
          console.log("🔔 Realtime cart update triggered")
          const {
            data: { user },
          } = await supabase.auth.getUser()

          if (!user) return

          const { data } = await supabase
            .from("cart")
            .select(`*, products (*)`)
            .eq("user_id", user.id)
            .order("created_at", { ascending: false })

          if (data) {
            console.log("🆕 Updated cart data:", data)
            setCartItems(data)
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [supabase])

  // 🧮 UPDATE QUANTITY
  const updateQuantity = async (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) return
    setIsLoading(true)
    try {
      console.log(`✏️ Updating quantity for ${itemId} → ${newQuantity}`)
      const { error } = await supabase.from("cart").update({ quantity: newQuantity }).eq("id", itemId)
      if (error) throw error
      setCartItems(cartItems.map((i) => (i.id === itemId ? { ...i, quantity: newQuantity } : i)))
    } catch (err) {
      console.error("❌ Quantity update failed:", err)
      toast({
        title: "Error",
        description: "Failed to update quantity",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // 🗑️ REMOVE ITEM
  const removeItem = async (itemId: string) => {
    setIsLoading(true)
    try {
      console.log(`🗑️ Removing item: ${itemId}`)
      const { error } = await supabase.from("cart").delete().eq("id", itemId)
      if (error) throw error
      setCartItems(cartItems.filter((i) => i.id !== itemId))
      toast({ title: "Item removed", description: "Item has been removed from your cart" })
    } catch (err) {
      console.error("❌ Remove failed:", err)
      toast({
        title: "Error",
        description: "Failed to remove item",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // 💰 TOTALS
  const subtotal = cartItems.reduce(
    (sum, item) => sum + (item.products?.price || 0) * item.quantity,
    0
  )
  const shippingCharge = 80
  const total = subtotal + shippingCharge

  // 🛒 EMPTY CART VIEW
  if (cartItems.length === 0) {
    return (
      <motion.div
        className="max-w-7xl mx-auto px-6 text-center py-20 bg-[#EEEAE1]"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <ShoppingBag className="h-20 w-20 mx-auto text-[#3C4433]/30 mb-6" />
        <h1 className="text-3xl font-serif text-[#0A0A0A] mb-3">Your Cart is Empty</h1>
        <p className="text-[#0A0A0A]/60 mb-8 text-sm sm:text-base">
          Add some products to your cart to get started.
        </p>
        <Button
          onClick={() => router.push("/products")}
          className="bg-[#3C4433] text-[#EEEAE1] hover:bg-[#0A0A0A] rounded-none"
        >
          Continue Shopping
        </Button>
      </motion.div>
    )
  }

  // 🧾 FILLED CART VIEW
  return (
    <>
      <div className="max-w-7xl mx-auto px-6 py-12 bg-[#EEEAE1]">
        <motion.h1
          className="text-3xl md:text-4xl font-serif text-[#0A0A0A] mb-10 text-center"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Shopping Cart
        </motion.h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-10">
          {/* 🧺 CART ITEMS */}
          <motion.div
            className="lg:col-span-2 space-y-4"
            initial="hidden"
            animate="visible"
            variants={{ visible: { transition: { staggerChildren: 0.1 } } }}
          >
            {cartItems.map((item) => (
              <motion.div
                key={item.id}
                variants={{
                  hidden: { opacity: 0, x: -20 },
                  visible: { opacity: 1, x: 0 },
                }}
                transition={{ duration: 0.4 }}
              >
                <Card className="bg-[#ffffff] border border-[#3C4433]/15 rounded-none shadow-sm hover:shadow-md transition-all duration-300">
                  <CardContent className="p-4 sm:p-6 flex gap-4 sm:gap-6 items-center">
                    <div className="relative w-24 h-24 sm:w-28 sm:h-28 bg-[#EEEAE1] border border-[#d9d4c8] overflow-hidden flex-shrink-0">
                      <Image
                        src={item.products?.image_url || "/placeholder.svg?height=96&width=96"}
                        alt={item.products?.name || "Product"}
                        fill
                        className="object-cover object-center"
                      />
                    </div>

                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <h3 className="font-serif text-base md:text-lg text-[#0A0A0A] mb-1">
                          {item.products?.name}
                        </h3>
                        <p className="text-sm text-[#0A0A0A]/70 mb-3">
                          ₹{item.products?.price} each
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 border-[#3C4433]/30 bg-transparent hover:bg-[#EEEAE1]/70 rounded-none"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          disabled={isLoading || item.quantity <= 1}
                        >
                          <Minus className="h-3 w-3 text-[#3C4433]" />
                        </Button>
                        <span className="w-8 text-center text-sm font-medium text-[#0A0A0A]">
                          {item.quantity}
                        </span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 border-[#3C4433]/30 bg-transparent hover:bg-[#EEEAE1]/70 rounded-none"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          disabled={isLoading || item.quantity >= (item.products?.stock || 0)}
                        >
                          <Plus className="h-3 w-3 text-[#3C4433]" />
                        </Button>
                      </div>
                    </div>

                    <div className="flex flex-col justify-between items-end">
                      <p className="font-medium text-[#0A0A0A]">
                        ₹{((item.products?.price || 0) * item.quantity).toFixed(2)}
                      </p>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-[#3C4433]/60 hover:text-[#0A0A0A]"
                        onClick={() => removeItem(item.id)}
                        disabled={isLoading}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>

          {/* 💳 ORDER SUMMARY */}
          <motion.div
            className="lg:col-span-1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="bg-[#ffffff] border border-[#3C4433]/15 rounded-none shadow-sm sticky top-20">
              <CardContent className="p-6 sm:p-8">
                <h2 className="text-xl font-serif text-[#0A0A0A] mb-4">Order Summary</h2>
                <div className="space-y-3 mb-6 text-sm text-[#0A0A0A]/80">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>₹{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>₹{shippingCharge.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-[#3C4433]/10 pt-3 mt-2">
                    <div className="flex justify-between text-base font-medium text-[#0A0A0A]">
                      <span>Total</span>
                      <span>₹{total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <Button
                  className="w-full bg-[#3C4433] text-[#EEEAE1] hover:bg-[#0A0A0A] rounded-none"
                  onClick={() => setShowCheckout(true)}
                  disabled={isLoading}
                >
                  Proceed to Checkout
                </Button>

                <Button
                  variant="outline"
                  className="w-full mt-3 border-[#3C4433]/40 text-[#0A0A0A] hover:bg-[#EEEAE1]/40 rounded-none"
                  onClick={() => router.push("/products")}
                >
                  Continue Shopping
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      <CheckoutModal
        open={showCheckout}
        onOpenChange={setShowCheckout}
        cartItems={cartItems}
        subtotal={subtotal}
        shippingCharge={shippingCharge}
        total={total}
        userProfile={userProfile}
      />
    </>
  )
}
