// "use client"

// import Link from "next/link"
// import { Instagram, Twitter, Facebook, Mail, Phone } from "lucide-react"

// export function Footer() {
//   return (
//     <footer className="bg-[#0A0A0A] text-white py-12 mt-auto">
//       <div className="max-w-6xl mx-auto px-6 lg:px-8">
//         {/* Top Section */}
//         <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10">
//           {/* Brand */}
//             <div>
//               <Link href="/" className="inline-block">
//                 <img src="/logo-footer.PNG" alt="Qura Herbs logo" className="h-10 mb-2 rounded-full" />
//               </Link>
//             {/* <h3 className="text-lg font-semibold mb-2 tracking-wide">
//               Qura Herbs
//             </h3> */}
//             <p className="text-sm text-gray-400 leading-relaxed">
//               Redefining beauty, naturally.
//             </p>

//             {/* Social Media */}
//             <div className="flex items-center gap-4 mt-5">
//               <Link
//                 href="https://www.instagram.com/qura_herbs?igsh=aXM0MGlpNm8zbTU2"
//                 target="_blank"
//                 rel="noopener noreferrer"
//                 className="text-gray-400 hover:text-[#EEEAE1] transition-colors"
//               >
//                 <Instagram className="h-5 w-5" />
//               </Link>
//               {/* <Link
//                 href="https://x.com/quraherbs"
//                 target="_blank"
//                 rel="noopener noreferrer"
//                 className="text-gray-400 hover:text-[#EEEAE1] transition-colors"
//               >
//                 <Twitter className="h-5 w-5" />
//               </Link> */}
//               <Link
//                 href="https://m.facebook.com/61577220473644/"
//                 target="_blank"
//                 rel="noopener noreferrer"
//                 className="text-gray-400 hover:text-[#EEEAE1] transition-colors"
//               >
//                 <Facebook className="h-5 w-5" />
//               </Link>
//             </div>
//           </div>

//           {/* Quick Links */}
//           <div>
//             <h4 className="text-sm font-semibold text-gray-200 mb-3 tracking-wider uppercase">
//               Quick Links
//             </h4>
//             <ul className="space-y-2">
//               <li>
//                 <Link
//                   href="/"
//                   className="text-sm text-gray-400 hover:text-white transition-colors"
//                 >
//                   Home
//                 </Link>
//               </li>
//               <li>
//                 <Link
//                   href="/about"
//                   className="text-sm text-gray-400 hover:text-white transition-colors"
//                 >
//                   About
//                 </Link>
//               </li>
//               <li>
//                 <Link
//                   href="/products"
//                   className="text-sm text-gray-400 hover:text-white transition-colors"
//                 >
//                   Products
//                 </Link>
//               </li>
//               <li>
//                 <Link
//                   href="/orders"
//                   className="text-sm text-gray-400 hover:text-white transition-colors"
//                 >
//                   Orders
//                 </Link>
//               </li>
//             </ul>
//           </div>

//           {/* Contact Info */}
//             <div>
//             <h4 className="text-sm font-semibold text-gray-200 mb-3 tracking-wider uppercase">
//               Contact
//             </h4>
//             <ul className="space-y-2 text-sm text-gray-400">
//               <li className="flex items-center gap-3">
//               <Mail className="h-4 w-4 text-gray-400" />
//               <a
//                 href="mailto:quraherbs@gmail.com"
//                 className="hover:text-white underline underline-offset-2"
//               >
//                 quraherbs@gmail.com
//               </a>
//               </li>
//               <li className="flex items-center gap-3">
//               <Phone className="h-4 w-4 text-gray-400" />
//               <a href="tel:+91 82486 92114" className="hover:text-white">
//                +91 82486 92114
//               </a>
//               </li>
//             </ul>
//             </div>
//         </div>

//         {/* Divider */}
//         <div className="border-t border-gray-800 pt-6 text-center">
//           <p className="text-xs text-gray-500">
//             © {new Date().getFullYear()} Qura Herbs. All rights reserved.
//           </p>
//         </div>
//       </div>
//     </footer>
//   )
// }
"use client"

import Link from "next/link"
import { Instagram, Facebook, Mail, Phone } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-[#EEEAE1] text-[#0A0A0A] py-12 mt-auto">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        {/* Top Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10">
          {/* Brand */}
          <div>
            <Link href="/" className="inline-block">
              <img
                src="/logo-footer.PNG"
                alt="Qura Herbs logo"
                className="h-10 mb-3 rounded-full"
              />
            </Link>
            <p className="text-sm text-[#0A0A0A]/70 leading-relaxed">
              Redefining beauty, naturally.
            </p>

            {/* Social Media */}
            <div className="flex items-center gap-4 mt-5">
              <Link
                href="https://www.instagram.com/qura_herbs?igsh=aXM0MGlpNm8zbTU2"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#0A0A0A]/70 hover:text-[#0A0A0A] transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </Link>
              <Link
                href="https://m.facebook.com/61577220473644/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#0A0A0A]/70 hover:text-[#0A0A0A] transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </Link>
              <Link
                href="https://wa.me/918248692114"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#0A0A0A]/70 hover:text-[#0A0A0A] transition-colors"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-semibold text-[#0A0A0A] mb-3 tracking-wider uppercase">
              Quick Links
            </h4>
            <ul className="space-y-2">
              {[
                { name: "Home", href: "/" },
                { name: "About", href: "/about" },
                { name: "Products", href: "/products" },
                { name: "Orders", href: "/orders" },
              ].map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-[#0A0A0A]/70 hover:text-[#0A0A0A] transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-sm font-semibold text-[#0A0A0A] mb-3 tracking-wider uppercase">
              Contact
            </h4>
            <ul className="space-y-2 text-sm text-[#0A0A0A]/70">
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-[#0A0A0A]/60" />
                <a
                  href="mailto:quraherbs@gmail.com"
                  className="hover:text-[#0A0A0A] underline underline-offset-2"
                >
                  quraherbs@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-[#0A0A0A]/60" />
                <a
                  href="tel:+918248692114"
                  className="hover:text-[#0A0A0A]"
                >
                  +91 82486 92114
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-[#0A0A0A]/10 pt-6 text-center">
          <p className="text-xs text-[#0A0A0A]/50">
            © {new Date().getFullYear()} Qura Herbs. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}