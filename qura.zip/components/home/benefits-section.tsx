"use client"

import Image from "next/image"
import { Playfair_Display } from "next/font/google"
import { CheckCircle } from "lucide-react"
import { motion } from "framer-motion"

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
})

export default function TipsSection() {
  return (
    <section
      className={`${playfair.variable} w-full py-14 md:py-20 bg-[#EEEAE1] text-[#0A0A0A] flex flex-col items-center justify-center`}
    >
      <div className="w-full max-w-7xl mx-auto px-6 md:px-0 grid md:grid-cols-2 gap-12 md:gap-16 items-center">
        {/* LEFT CONTENT */}
        <div>
          <h2 className="font-serif text-[#0A0A0A] text-4xl sm:text-5xl md:text-6xl leading-tight tracking-tight">
            Simple Skin Tips
          </h2>

          <p className="mt-3 text-[11px] sm:text-xs tracking-[0.25em] text-[#3C4433] uppercase">
            Everyday care for naturally radiant skin
          </p>

          <ul className="mt-8 space-y-4 text-sm md:text-base opacity-80 leading-relaxed list-disc list-inside text-[#0A0A0A]">
            <li>Stay hydrated throughout the day.</li>
            <li>Use sunscreen every morning — even indoors.</li>
            <li>Cleanse your face gently without over-drying.</li>
            <li>Moisturize regularly to lock in hydration.</li>
          </ul>
        </div>

        {/* RIGHT IMAGE WITH FLOATING CARD */}
        <div className="relative">
          <div className="relative  overflow-hidden border border-[#3C4433]/25 shadow-[0_6px_20px_rgba(0,0,0,0.05)] bg-[#EEEAE1]">
            <div className="relative aspect-[4/3] md:aspect-[4/3]">
              <Image
                src="/hero/skin/qura-girl.webp"
                alt="Person applying skincare in natural light"
                fill
                className="object-cover object-center"
                priority
              />
            </div>
          </div>

          {/* FLOATING INFO CARD (RIGHT-BOTTOM, LIFTED POSITION) */}
          {/* <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="absolute bottom-10 right-6 bg-[#EEEAE1]/95 backdrop-blur-md   border border-[#3C4433]/20 shadow-[0_8px_30px_rgba(0,0,0,0.1)] p-4 md:p-5 w-[240px] md:w-[260px]"
          >
            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-[#3C4433] flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-sm font-semibold text-[#0A0A0A]">Proven</h3>
                <p className="italic text-[#0A0A0A] text-sm">Effectiveness</p>
                <p className="text-[11px] text-[#0A0A0A]/70 mt-1 leading-snug">
                  Every product is carefully crafted to meet the highest quality standards.
                </p>
              </div>
            </div>
          </motion.div> */}
        </div>
      </div>

      {/* BOTTOM SPACING */}
      <div className="h-10 md:h-14" />
    </section>
  )
}
