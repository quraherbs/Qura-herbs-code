"use client"

import Link from "next/link"
import { ArrowUpRight } from "lucide-react"
import { cn } from "@/lib/utils"
import { Playfair_Display } from "next/font/google"

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
})

type Props = {
  className?: string
  ctaHref?: string
}

export function Greetings({ className, ctaHref = "https://wa.me/918248692114" }: Props) {
  return (
    <section
      className={cn(
        `${playfair.variable} relative w-full bg-[#EEEAE1] flex flex-col items-center justify-center px-6 overflow-hidden pb-20`,
        className
      )}
      aria-label="Intro hero copy"
    >
      {/* Main Card */}
      <div className="relative z-10 w-full max-w-4xl md:max-w-5xl rounded-2xl border border-[#0A0A0A]/20 bg-[#EEEAE1] shadow-[0_1px_0_0_rgba(10,10,10,0.08)] p-8 sm:p-10 md:p-16 overflow-hidden">
        {/* Text Content */}
        <div className="relative z-10 text-center">
          <h1 className="font-serif text-[#0A0A0A] text-4xl sm:text-5xl md:text-7xl leading-tight tracking-tight">
            Hey. Hi. Hello
          </h1>

          <p className="mt-4 text-[10px] sm:text-[11px] md:text-xs tracking-[0.25em] text-[#0A0A0A]/70 uppercase">
            We&apos;re Qura Herbs — your skin protector! <br />
           any queries? Feel free to ask us on WhatsApp
          </p>

          <Link
            href={ctaHref}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Contact Us on WhatsApp"
            className="mt-8 inline-flex items-center justify-center group"
          >
            <span className="block text-[#0A0A0A] font-serif text-xl sm:text-2xl md:text-3xl leading-[1.15] text-center">
              CONTACT US
            </span>
            <span className="ml-3 inline-flex h-7 w-7 items-center justify-center rounded-full border border-[#0A0A0A] transition-colors group-hover:bg-[#0A0A0A]">
              <ArrowUpRight
                className="h-4 w-4 text-[#0A0A0A] transition-colors group-hover:text-[#EEEAE1]"
                aria-hidden="true"
              />
            </span>
          </Link>
        </div>
      </div>
    </section>
  )
}

export default Greetings