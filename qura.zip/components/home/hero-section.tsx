"use client"

import { useState, useEffect, useRef } from "react"
import { ArrowLeft, ArrowRight } from "lucide-react"

const slides = [
  {
    title: "Natural",
    subtitle: "Skincare",
    description:
      "Start your day with gentle care and nourishing ingredients designed to awaken your skin naturally.",
    image: "/hero/qura-banner-001.webp",
  },
  {
    title: "Refresh",
    subtitle: "Your Skin",
    description:
      "Skincare stripped to the essentials — clean, effective, and made with nature in mind.",
    image: "/hero/girl-hero-2.avif",
  },
]

export default function HeroSection() {
  const [current, setCurrent] = useState(0)
  const [animateText, setAnimateText] = useState(true)
  const [isTransitioning, setIsTransitioning] = useState(true)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)
  const heroRef = useRef<HTMLDivElement | null>(null)

  // --- Parallax Effect ---
  useEffect(() => {
    const hero = heroRef.current
    if (!hero) return

    const parallaxImages = hero.querySelectorAll("[data-parallax='image']")
    const parallaxText = hero.querySelectorAll("[data-parallax='text']")

    const onScroll = () => {
      const rect = hero.getBoundingClientRect()
      const scrollTop = -rect.top
      const imageOffset = scrollTop * 0.4
      const textOffset = scrollTop * 0.15

      parallaxImages.forEach((el) => {
        ;(el as HTMLElement).style.transform = `translateY(${imageOffset}px)`
      })
      parallaxText.forEach((el) => {
        ;(el as HTMLElement).style.transform = `translateY(${textOffset}px)`
      })
    }

    const onScrollRaf = () => requestAnimationFrame(onScroll)
    window.addEventListener("scroll", onScrollRaf, { passive: true })
    return () => window.removeEventListener("scroll", onScrollRaf)
  }, [])

  // --- Slider Logic ---
  const extendedSlides = [...slides, slides[0]]

  useEffect(() => {
    const interval = setInterval(() => nextSlide(), 7000)
    return () => clearInterval(interval)
  }, [current])

  const nextSlide = () => {
    setAnimateText(false)
    setIsTransitioning(true)
    setCurrent((prev) => prev + 1)
    setTimeout(() => setAnimateText(true), 100)

    if (current === slides.length - 1) {
      timeoutRef.current = setTimeout(() => {
        setIsTransitioning(false)
        setCurrent(0)
        setTimeout(() => setIsTransitioning(true), 50)
      }, 1000)
    }
  }

  const prevSlide = () => {
    setAnimateText(false)
    if (current === 0) {
      setIsTransitioning(false)
      setCurrent(slides.length)
      setTimeout(() => {
        setIsTransitioning(true)
        setCurrent(slides.length - 1)
        setAnimateText(true)
      }, 50)
    } else {
      setIsTransitioning(true)
      setCurrent((prev) => prev - 1)
      setTimeout(() => setAnimateText(true), 100)
    }
  }

  const goToSlide = (index: number) => {
    setAnimateText(false)
    setIsTransitioning(true)
    setCurrent(index)
    setTimeout(() => setAnimateText(true), 100)
  }

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current)
    }
  }, [])

  const displayIndex = current >= slides.length ? 0 : current
  const slide = slides[displayIndex]

  return (
    <div className="min-h-screen bg-[#EEEAE1]">
      <section
        ref={heroRef}
        className="relative w-full h-screen overflow-hidden bg-[#EEEAE1] text-[#0A0A0A]"
      >
        {/* --- Image Slider --- */}
        <div
          className={`absolute inset-0 flex ${
            isTransitioning
              ? "transition-transform duration-[1000ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
              : ""
          }`}
          style={{
            transform: `translateX(-${current * 100}%)`,
            willChange: "transform",
          }}
        >
          {extendedSlides.map((slideItem, index) => (
            <div
              key={index}
              className="relative flex-shrink-0 w-full h-screen will-change-transform"
              data-parallax="image"
            >
              <img
                src={slideItem.image}
                alt={slideItem.title}
                className="absolute inset-0 w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-[#0A0A0A]/20" />
            </div>
          ))}
        </div>

        {/* --- Text Content --- */}
        <div
          className="relative z-10 flex flex-col justify-center h-full max-w-7xl mx-auto px-6 lg:px-0 will-change-transform"
          data-parallax="text"
        >
          <div
            key={slide.title + displayIndex}
            className={`transition-all duration-[1200ms] ease-[cubic-bezier(0.4,0,0.2,1)] ${
              animateText
                ? "opacity-100 blur-0 translate-y-0"
                : "opacity-0 blur-sm translate-y-3"
            }`}
          >
            <h1 className="font-serif text-5xl md:text-7xl font-semibold text-[#EEEAE1] leading-tight drop-shadow-lg">
              {slide.title}{" "}
              <span className="italic font-light text-[#EEEAE1]/90">
                {slide.subtitle}
              </span>
            </h1>
            <p className="mt-4 text-[#EEEAE1]/80 text-base md:text-lg max-w-md leading-relaxed">
              {slide.description}
            </p>
            <div className="mt-8">
              <a
                href="/products"
                className="bg-[#EEEAE1] text-[#0A0A0A] hover:bg-transparent hover:text-[#EEEAE1] border border-[#EEEAE1] text-sm md:text-base px-8 py-4 rounded-none transition-all duration-700 font-light tracking-wide uppercase inline-block text-center"
              >
                Shop Now
              </a>
            </div>
          </div>
        </div>

        {/* --- Navigation Arrows --- */}
        {/* --- Navigation Arrows --- */}
<button
  onClick={prevSlide}
  className="hidden md:flex absolute left-6 top-1/2 -translate-y-1/2 bg-[#0A0A0A]/30 hover:bg-[#0A0A0A]/50 backdrop-blur-md rounded-md p-2 transition-colors z-20"
>
  <ArrowLeft className="text-[#EEEAE1] h-5 w-5" />
</button>

<button
  onClick={nextSlide}
  className="hidden md:flex absolute right-6 top-1/2 -translate-y-1/2 bg-[#0A0A0A]/30 hover:bg-[#0A0A0A]/50 backdrop-blur-md rounded-md p-2 transition-colors z-20"
>
  <ArrowRight className="text-[#EEEAE1] h-5 w-5" />
</button>


        {/* --- Bottom Dots --- */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 bg-[#3C4433]/25 backdrop-blur-md rounded-full px-3 py-1 flex gap-2 z-20">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => goToSlide(i)}
              className={`h-2.5 w-2.5 rounded-full transition-all duration-500 ${
                i === displayIndex ? "bg-[#EEEAE1]" : "bg-[#EEEAE1]/40"
              }`}
            />
          ))}
        </div>
      </section>
    </div>
  )
}
