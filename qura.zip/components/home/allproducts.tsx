"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart } from "lucide-react"
import { Playfair_Display } from "next/font/google"
import { cn } from "@/lib/utils"

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
})

type Product = {
  id: string | number
  name: string
  price: number
  originalPrice?: number
  discount?: string
  image_url?: string | null
  category?: string
}

const placeholderList: Product[] = [
  { 
    id: "silk-lotion", 
    name: "Silk Lotion", 
    price: 9.90, 
    image_url: "/hero/product-sample.webp",
    category: "Lotions"
  },
  { 
    id: "glow-milk", 
    name: "Glow Milk", 
    price: 9.90,
    originalPrice: 23.00,
    discount: "57% OFF",
    image_url: "/hero/product-sample.webp",
    category: "Lotions"
  },
  { 
    id: "balance-mist", 
    name: "Balance Mist", 
    price: 7.90,
    image_url: "/hero/product-sample.webp",
    category: "Moisturizers"
  },
]

export default function MeetTheSkeen({ products }: { products?: Product[] }) {
  const items = products && products.length ? products : placeholderList
  const [activeTab, setActiveTab] = useState("Lotions")
  const [scrollY, setScrollY] = useState(0)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect()
        const scrollProgress = -rect.top / (rect.height / 2)
        setScrollY(Math.max(0, Math.min(1, scrollProgress)))
      }
    }

    window.addEventListener("scroll", handleScroll)
    handleScroll()
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const filteredItems = items.filter(item => 
    !activeTab || activeTab === "All" || item.category === activeTab
  )

  const tabs = ["Cleansers", "Lotions", "Moisturizers"]

  return (
    <section 
      ref={sectionRef}
      className={cn(`${playfair.variable} w-full py-20 md:py-24 bg-[#F5F3EF] text-[#0A0A0A] relative overflow-hidden`)}
    >
      {/* Parallax Background Elements */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          transform: `translateY(${scrollY * 50}px)`,
          opacity: 0.6
        }}
      >
        <div className="absolute top-20 left-10 w-32 h-32 bg-[#CBBBA2]/20 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-[#CBBBA2]/20 rounded-full blur-3xl" />
      </div>

      <div 
        className="w-full max-w-6xl mx-auto px-6 relative"
        style={{
          transform: `translateY(${scrollY * -20}px)`,
        }}
      >
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl md:text-5xl leading-tight tracking-tight">
            All Products
          </h2>
          <p className="mt-3 text-sm text-[#0A0A0A]/70 uppercase tracking-widest">
            Discover all our handcrafted blends for radiant, balanced skin.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex justify-center gap-4 mb-12">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "px-6 py-2 text-sm font-medium rounded-md transition-all duration-300",
                activeTab === tab
                  ? "bg-[#3C4433] text-white"
                  : "bg-[#E5E1D8] text-[#0A0A0A] hover:bg-[#D5D1C8]"
              )}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 justify-center">
          {filteredItems.map((product, index) => (
            <Link
              key={product.id}
              href={`/products/${product.id}`}
              className="group relative"
              style={{
                transform: `translateY(${scrollY * (index % 2 === 0 ? 10 : -10)}px)`,
                transition: "transform 0.3s ease-out"
              }}
            >
              {/* Product Card */}
              <div className="relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500">
                {/* Wishlist Heart */}
                <button className="absolute top-4 left-4 z-10 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors">
                  <Heart className="w-5 h-5 text-gray-600" />
                </button>

                {/* Discount Badge */}
                {product.discount && (
                  <div className="absolute top-4 right-4 z-10 bg-[#0A0A0A] text-white text-xs font-semibold px-3 py-1.5 rounded-full">
                    {product.discount}
                  </div>
                )}

                {/* Product Image */}
                <div className="relative w-full aspect-square bg-gradient-to-br from-[#F5E6D3] to-[#E8D5B8] overflow-hidden">
                  <Image
                    src={product.image_url || "/placeholder.svg"}
                    alt={product.name}
                    fill
                    className="object-cover object-center transition-transform duration-700 group-hover:scale-110"
                  />
                </div>

                {/* Product Info */}
                <div className="p-6 text-center">
                  <h3 className="text-xl font-serif font-medium text-[#0A0A0A] mb-2">
                    {product.name}
                  </h3>
                  <div className="flex items-center justify-center gap-2">
                    <p className="text-lg font-semibold text-[#0A0A0A]">
                      {product.price.toFixed(2)} €
                    </p>
                    {product.originalPrice && (
                      <p className="text-sm text-gray-400 line-through">
                        {product.originalPrice.toFixed(2)} €
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Shop More Link */}
        <div className="text-center mt-16">
          <Link 
            href="/products" 
            className="inline-block text-sm font-medium text-[#0A0A0A] underline underline-offset-4 hover:underline-offset-8 transition-all duration-300"
          >
            Shop Lotions
          </Link>
        </div>
      </div>
    </section>
  )
}