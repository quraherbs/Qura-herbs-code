"use client"

import Image from "next/image"
import Link from "next/link"
import { Playfair_Display } from "next/font/google"
import { cn } from "@/lib/utils"

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
})

type Product = {
  id: string | number
  name: string
  price: number
  image_url?: string | null
}

function fallbackProducts(): Product[] {
  return [
    { id: 1, name: "Oil", price: 2499, image_url: "/images/shop-all.jpg" },
    { id: 2, name: "Serum", price: 2999, image_url: "/images/best-sellers.jpg" },
    { id: 3, name: "Daily Set", price: 4599, image_url: "/images/value-combos.jpg" },
    { id: 4, name: "Bath Rituals", price: 3799, image_url: "/images/bath-rituals.jpg" },
    { id: 5, name: "Everyday Care", price: 1999, image_url: "/images/everyday-care.jpg" },
    { id: 6, name: "Glow Elixir", price: 3299, image_url: "/images/glow-elixir.jpg" },
    { id: 7, name: "Herbal Cleanser", price: 1899, image_url: "/images/herbal-cleanser.jpg" },
    { id: 8, name: "Healing Balm", price: 1599, image_url: "/images/healing-balm.jpg" },
  ]
}

export default function AllProducts({ products }: { products?: Product[] }) {
  const items = products && products.length ? products : fallbackProducts()

  return (
    <section
      className={cn(
        `${playfair.variable} w-full py-10 md:py-14 bg-[#EEEAE1] text-[#0A0A0A] flex flex-col items-center justify-center`
      )}
      aria-label="All products section"
    >
      {/* Section Header */}
      <div className="w-full max-w-7xl mx-auto text-center px-6 md:px-0">
        <h2 className="font-serif text-[#0A0A0A] text-4xl sm:text-5xl md:text-6xl leading-tight tracking-tight">
          Our Products
        </h2>
        <p className="mt-2 text-[11px] sm:text-xs tracking-[0.25em] text-[#3C4433] uppercase">
          Explore our full range of botanical skincare
        </p>
      </div>

      {/* Product Slider */}
      <div
        className="
          mt-10 flex overflow-x-auto scroll-smooth no-scrollbar gap-6 md:gap-10
          w-full md:max-w-7xl px-4 md:px-0
        "
      >
        {items.map((p, idx) => (
          <Link
            key={p.id}
            href={`/products/${p.id}`}
            className={cn(
              "flex-shrink-0 flex flex-col items-center transition-none",
              "w-[calc(50%-0.75rem)] sm:w-[calc(50%-1rem)] md:w-[23%]",
              idx === 0 && "ml-2 md:ml-0",
              idx === items.length - 1 && "mr-2 md:mr-0"
            )}
          >
            {/* Arch Image */}
            <div
              className="
                relative w-full h-[200px] sm:h-[240px] md:h-[300px]
                overflow-hidden rounded-t-full border border-[#3C4433]/25 bg-[#EEEAE1]
                shadow-[0_6px_20px_rgba(0,0,0,0.05)]
              "
            >
              <Image
                src={
                  p.image_url ||
                  '/placeholder.svg?height=400&width=400&query=skincare%20product'
                }
                alt={p.name}
                fill
                className="object-cover object-center"
              />
            </div>

            {/* Product Info */}
            <div className="mt-3 text-center font-sans">
              <h3 className="text-sm sm:text-base md:text-lg text-[#0A0A0A] leading-snug font-medium">
                {p.name}
              </h3>
              <p className="text-xs sm:text-sm text-[#0A0A0A]/70 mt-1 font-light">
                ₹{p.price.toLocaleString('en-IN')}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}
