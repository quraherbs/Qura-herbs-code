"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Order, OrderItem } from "@/lib/types"
import { createClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import { Package } from "lucide-react"

interface OrderWithItems extends Order {
  order_items: OrderItem[]
}

interface AdminOrdersListProps {
  orders: OrderWithItems[]
}

export function AdminOrdersList({ orders: initialOrders }: AdminOrdersListProps) {
  const [orders, setOrders] = useState(initialOrders)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const supabase = createClient()

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    setIsLoading(true)
    try {
      const { error } = await supabase.from("orders").update({ status: newStatus }).eq("id", orderId)

      if (error) throw error

      setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order)))

      toast({
        title: "Order updated",
        description: `Order status changed to ${newStatus}`,
      })
    } catch (error) {
      console.error("[v0] Error updating order:", error)
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (orders.length === 0) {
    return (
      <div className="container mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-[#000000] mb-8">Manage Orders</h1>
        <div className="text-center py-16">
          <Package className="h-24 w-24 mx-auto text-[#ccbcaa] mb-6" />
          <h2 className="text-2xl font-bold text-[#000000] mb-4">No orders yet</h2>
          <p className="text-[#000000]/70">Orders will appear here once customers make purchases</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4">
      <h1 className="text-3xl md:text-4xl font-bold text-[#000000] mb-8">Manage Orders</h1>

      <div className="space-y-6">
        {orders.map((order) => (
          <Card key={order.id} className="border-[#ccbcaa]/20">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Order Info */}
                <div>
                  <h3 className="font-semibold text-[#000000] mb-4">Order #{order.id.slice(0, 8)}</h3>
                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="text-[#000000]/70">Customer: </span>
                      <span className="text-[#000000]">{order.full_name}</span>
                    </div>
                    <div>
                      <span className="text-[#000000]/70">Email: </span>
                      <span className="text-[#000000]">{order.email}</span>
                    </div>
                    <div>
                      <span className="text-[#000000]/70">Phone: </span>
                      <span className="text-[#000000]">{order.phone}</span>
                    </div>
                    <div>
                      <span className="text-[#000000]/70">Address: </span>
                      <span className="text-[#000000]">
                        {order.address}, {order.city}, {order.state} - {order.pincode}
                      </span>
                    </div>
                    <div>
                      <span className="text-[#000000]/70">Date: </span>
                      <span className="text-[#000000]">
                        {new Date(order.created_at).toLocaleDateString("en-IN", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Order Items & Status */}
                <div>
                  <h4 className="font-semibold text-[#000000] mb-3">Items</h4>
                  <div className="space-y-2 mb-4">
                    {order.order_items.map((item) => (
                      <div key={item.id} className="flex justify-between text-sm">
                        <span className="text-[#000000]/70">
                          {item.product_name} × {item.quantity}
                        </span>
                        <span className="text-[#000000]">₹{(item.product_price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-[#ccbcaa]/20 pt-3 mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-[#000000]/70">Subtotal</span>
                      <span className="text-[#000000]">₹{order.subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-[#000000]/70">Shipping</span>
                      <span className="text-[#000000]">₹{order.shipping_charge.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-[#000000]">
                      <span>Total</span>
                      <span>₹{order.total.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-[#000000]">Order Status</label>
                    <Select
                      value={order.status}
                      onValueChange={(value) => updateOrderStatus(order.id, value)}
                      disabled={isLoading}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="processing">Processing</SelectItem>
                        <SelectItem value="shipped">Shipped</SelectItem>
                        <SelectItem value="delivered">Delivered</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
