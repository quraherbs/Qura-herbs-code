"use client"

import Link from "next/link"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Product } from "@/lib/types"
import { motion } from "framer-motion"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <motion.div whileHover={{ y: -8, scale: 1.02 }} transition={{ duration: 0.3, ease: "easeOut" }}>
      <Card className="overflow-hidden border-[#ccbcaa]/20 hover:shadow-xl hover:border-[#ccbcaa]/40 transition-all duration-300 h-full group">
        <Link href={`/products/${product.id}`}>
          <div className="aspect-square relative bg-[#f0e9e2] overflow-hidden">
            <Image
              src={product.image_url || "/placeholder.svg?height=400&width=400"}
              alt={product.name}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-110"
            />
          </div>
        </Link>
        <CardContent className="p-4">
          <Link href={`/products/${product.id}`}>
            <motion.h3
              whileHover={{ x: 4 }}
              transition={{ duration: 0.2 }}
              className="text-lg font-semibold text-[#000000] mb-2 hover:text-[#ccbcaa] transition-colors font-serif"
            >
              {product.name}
            </motion.h3>
          </Link>
          <p className="text-[#000000]/70 text-sm mb-3 line-clamp-2">{product.description}</p>
          <div className="flex items-center justify-between">
            <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-xl font-bold text-[#000000]">
              ₹{product.price}
            </motion.span>
            <Link href={`/products/${product.id}`}>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  size="sm"
                  className="bg-[#000000] text-[#ffffff] hover:bg-[#ccbcaa] hover:text-[#000000] transition-all duration-300"
                >
                  View
                </Button>
              </motion.div>
            </Link>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
