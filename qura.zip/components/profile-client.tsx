// "use client"

// import type React from "react"

// import { useState } from "react"
// import { useRouter } from "next/navigation"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
// import { createClient } from "@/lib/supabase/client"
// import type { Profile } from "@/lib/types"
// import { useToast } from "@/hooks/use-toast"
// import { LogOut } from "lucide-react"

// interface ProfileClientProps {
//   profile: Profile | null
//   userEmail: string
// }

// export function ProfileClient({ profile, userEmail }: ProfileClientProps) {
//   const [formData, setFormData] = useState({
//     fullName: profile?.full_name || "",
//     phone: profile?.phone || "",
//     address: profile?.address || "",
//     city: profile?.city || "",
//     state: profile?.state || "",
//     pincode: profile?.pincode || "",
//   })
//   const [isLoading, setIsLoading] = useState(false)
//   const router = useRouter()
//   const { toast } = useToast()
//   const supabase = createClient()

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault()
//     setIsLoading(true)

//     try {
//       const {
//         data: { user },
//       } = await supabase.auth.getUser()
//       if (!user) throw new Error("Not authenticated")

//       const { error } = await supabase
//         .from("profiles")
//         .update({
//           full_name: formData.fullName,
//           phone: formData.phone,
//           address: formData.address,
//           city: formData.city,
//           state: formData.state,
//           pincode: formData.pincode,
//         })
//         .eq("id", user.id)

//       if (error) throw error

//       toast({
//         title: "Profile updated",
//         description: "Your profile has been updated successfully",
//       })

//       router.refresh()
//     } catch (error) {
//       console.error("[v0] Error updating profile:", error)
//       toast({
//         title: "Error",
//         description: "Failed to update profile",
//         variant: "destructive",
//       })
//     } finally {
//       setIsLoading(false)
//     }
//   }

//   const handleLogout = async () => {
//     await supabase.auth.signOut()
//     router.push("/")
//     router.refresh()
//   }

//   return (
//     <div className="container mx-auto px-4 max-w-2xl">
//       <div className="flex items-center justify-between mb-8">
//         <h1 className="text-3xl md:text-4xl font-bold text-[#000000]">My Profile</h1>
//         <Button
//           variant="outline"
//           onClick={handleLogout}
//           className="border-[#000000] text-[#000000] hover:bg-[#f0e9e2] bg-transparent"
//         >
//           <LogOut className="mr-2 h-4 w-4" />
//           Logout
//         </Button>
//       </div>

//       <Card className="border-[#ccbcaa]/20">
//         <CardHeader>
//           <CardTitle>Personal Information</CardTitle>
//         </CardHeader>
//         <CardContent>
//           <form onSubmit={handleSubmit} className="space-y-4">
//             <div className="space-y-2">
//               <Label htmlFor="email">Email</Label>
//               <Input id="email" type="email" value={userEmail} disabled className="bg-[#f0e9e2]" />
//             </div>

//             <div className="space-y-2">
//               <Label htmlFor="fullName">Full Name</Label>
//               <Input
//                 id="fullName"
//                 value={formData.fullName}
//                 onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
//               />
//             </div>

//             <div className="space-y-2">
//               <Label htmlFor="phone">Phone</Label>
//               <Input
//                 id="phone"
//                 type="tel"
//                 value={formData.phone}
//                 onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
//               />
//             </div>

//             <div className="space-y-2">
//               <Label htmlFor="address">Address</Label>
//               <Input
//                 id="address"
//                 value={formData.address}
//                 onChange={(e) => setFormData({ ...formData, address: e.target.value })}
//               />
//             </div>

//             <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//               <div className="space-y-2">
//                 <Label htmlFor="city">City</Label>
//                 <Input
//                   id="city"
//                   value={formData.city}
//                   onChange={(e) => setFormData({ ...formData, city: e.target.value })}
//                 />
//               </div>

//               <div className="space-y-2">
//                 <Label htmlFor="state">State</Label>
//                 <Input
//                   id="state"
//                   value={formData.state}
//                   onChange={(e) => setFormData({ ...formData, state: e.target.value })}
//                 />
//               </div>

//               <div className="space-y-2">
//                 <Label htmlFor="pincode">Pincode</Label>
//                 <Input
//                   id="pincode"
//                   value={formData.pincode}
//                   onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
//                 />
//               </div>
//             </div>

//             <Button
//               type="submit"
//               className="w-full bg-[#000000] text-[#ffffff] hover:bg-[#ccbcaa] hover:text-[#000000]"
//               disabled={isLoading}
//             >
//               {isLoading ? "Saving..." : "Save Changes"}
//             </Button>
//           </form>
//         </CardContent>
//       </Card>
//     </div>
//   )
// }

"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { createClient } from "@/lib/supabase/client"
import type { Profile } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"
import { LogOut } from "lucide-react"

interface ProfileClientProps {
  profile: Profile | null
  userEmail: string
}

export function ProfileClient({ profile, userEmail }: ProfileClientProps) {
  const [formData, setFormData] = useState({
    fullName: profile?.full_name || "",
    phone: profile?.phone || "",
    address: profile?.address || "",
    city: profile?.city || "",
    state: profile?.state || "",
    pincode: profile?.pincode || "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Not authenticated")

      const { error } = await supabase
        .from("profiles")
        .update({
          full_name: formData.fullName,
          phone: formData.phone,
          address: formData.address,
          city: formData.city,
          state: formData.state,
          pincode: formData.pincode,
        })
        .eq("id", user.id)

      if (error) throw error

      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      })

      router.refresh()
    } catch (error) {
      console.error("[v0] Error updating profile:", error)
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/")
    router.refresh()
  }

  return (
    <div className="max-w-2xl mx-auto w-full">
      {/* Header */}
      <div className="flex items-center justify-between mb-10">
        <h1 className="text-3xl md:text-4xl font-serif text-[#0A0A0A] tracking-tight">
          My Profile
        </h1>
        <Button
          variant="outline"
          onClick={handleLogout}
          className="border-[#3C4433]/40 text-[#0A0A0A] hover:bg-[#EEEAE1]/60 bg-transparent cursor-pointer rounded-none"
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </div>

      {/* Profile Form */}
      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Email */}
        <div className="space-y-2">
          <Label htmlFor="email" className="text-[#0A0A0A]/80">
            Email
          </Label>
          <Input
            id="email"
            type="email"
            value={userEmail}
            disabled
            className="bg-[#EEEAE1]/80 border border-[#3C4433]/20 text-[#0A0A0A] rounded-none"
          />
        </div>

        {/* Full Name */}
        <div className="space-y-2">
          <Label htmlFor="fullName" className="text-[#0A0A0A]/80">
            Full Name
          </Label>
          <Input
            id="fullName"
            value={formData.fullName}
            onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
            className="bg-[#EEEAE1]/50 border border-[#3C4433]/20 text-[#0A0A0A] rounded-none"
          />
        </div>

        {/* Phone */}
        <div className="space-y-2">
          <Label htmlFor="phone" className="text-[#0A0A0A]/80">
            Phone
          </Label>
          <Input
            id="phone"
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            className="bg-[#EEEAE1]/50 border border-[#3C4433]/20 text-[#0A0A0A] rounded-none"
          />
        </div>

        {/* Address */}
        <div className="space-y-2">
          <Label htmlFor="address" className="text-[#0A0A0A]/80">
            Address
          </Label>
          <Input
            id="address"
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            className="bg-[#EEEAE1]/50 border border-[#3C4433]/20 text-[#0A0A0A] rounded-none"
          />
        </div>

        {/* City / State / Pincode */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label htmlFor="city" className="text-[#0A0A0A]/80">
              City
            </Label>
            <Input
              id="city"
              value={formData.city}
              onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              className="bg-[#EEEAE1]/50 border border-[#3C4433]/20 text-[#0A0A0A] rounded-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="state" className="text-[#0A0A0A]/80">
              State
            </Label>
            <Input
              id="state"
              value={formData.state}
              onChange={(e) => setFormData({ ...formData, state: e.target.value })}
              className="bg-[#EEEAE1]/50 border border-[#3C4433]/20 text-[#0A0A0A] rounded-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="pincode" className="text-[#0A0A0A]/80">
              Pincode
            </Label>
            <Input
              id="pincode"
              value={formData.pincode}
              onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
              className="bg-[#EEEAE1]/50 border border-[#3C4433]/20 text-[#0A0A0A] rounded-none"
            />
          </div>
        </div>

        {/* Save Button */}
        <Button
          type="submit"
          className="w-full bg-[#3C4433] text-[#EEEAE1] hover:bg-[#0A0A0A] hover:text-[#EEEAE1] transition-all duration-300 rounded-none cursor-pointer"
          disabled={isLoading}
        >
          {isLoading ? "Saving..." : "Save Changes"}
        </Button>
      </form>
    </div>
  )
}
