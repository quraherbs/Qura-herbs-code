"use client"

import Link from "next/link"
import { ShoppingCart, User, Menu, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState, useEffect } from "react"
import { usePathname, useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function Header() {
  const [cartCount, setCartCount] = useState(0)
  const [user, setUser] = useState<any>(null)
  const [isHeroVisible, setIsHeroVisible] = useState(false)
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    async function fetchUserAndCart() {
      const { data } = await supabase.auth.getUser()
      if (data.user) {
        setUser(data.user)
        await updateCartCount(data.user.id)
      } else {
        setUser(null)
        setCartCount(0)
      }
    }

    async function updateCartCount(userId: string) {
      const { data: cartData } = await supabase
        .from("cart")
        .select("quantity")
        .eq("user_id", userId)

      if (cartData) {
        const total = cartData.reduce((sum, item) => sum + item.quantity, 0)
        setCartCount(total)
      }
    }

    fetchUserAndCart()

    const { data: authListener } = supabase.auth.onAuthStateChange(() => {
      fetchUserAndCart()
    })

    const channel = supabase
      .channel("cart-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "cart" }, async () => {
        const { data } = await supabase.auth.getUser()
        if (data.user) await updateCartCount(data.user.id)
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
      authListener?.subscription.unsubscribe()
    }
  }, [])

  // 🧠 Scroll detection only on Home Page
  useEffect(() => {
    if (pathname !== "/") return
    const handleScroll = () => setIsHeroVisible(window.scrollY < window.innerHeight * 0.95)
    handleScroll()
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [pathname])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    setUser(null)
    router.push("/")
  }

  // 🌈 Text & border color logic
  const isHome = pathname === "/"
  const textColor = isHome && isHeroVisible ? "#EEEAE1" : "#0A0A0A"
  const borderColor = isHome && isHeroVisible ? "border-white/20" : "border-[#0A0A0A]/20"

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/about", label: "About" },
    { href: "/products", label: "Products" },
    { href: "/orders", label: "Orders" },
  ]

  return (
    <header className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-full">
      <div className="mx-auto max-w-7xl px-6 md:px-0">
        <div
          className={`backdrop-blur-xl bg-transparent ${borderColor} border rounded-2xl shadow-[0_8px_32px_rgba(0,0,0,0.15)] transition-all duration-500`}
        >
          <div className="flex items-center justify-between h-14 px-4 sm:px-6">
            {/* MOBILE MENU */}
            <div className="flex items-center md:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="hover:bg-transparent"
                    style={{ color: textColor }}
                  >
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>

                <SheetContent
                  side="top"
                  className={`backdrop-blur-xl bg-transparent ${borderColor} border-b h-1/2 flex flex-col items-center justify-center`}
                >
                  <nav className="flex flex-col items-start gap-4 w-full max-w-xs">
                    {navLinks.map((link) => (
                      <Link
                        key={link.href}
                        href={link.href}
                        className="text-left text-base font-medium uppercase tracking-wide cursor-pointer transition-all duration-200"
                        style={{ color: textColor }}
                      >
                        {link.label}
                      </Link>
                    ))}

                    {user ? (
                      <>
                        <Link
                          href="/cart"
                          className="text-left text-base uppercase"
                          style={{ color: textColor }}
                        >
                          Cart {cartCount > 0 && `(${cartCount})`}
                        </Link>
                        <Link
                          href="/profile"
                          className="text-left text-base uppercase"
                          style={{ color: textColor }}
                        >
                          Profile
                        </Link>
                        {/* Mobile Logout Button */}
                        <Button
                          onClick={handleLogout}
                          variant="outline"
                          className="mt-3 border-[#3C4433]/40 text-[#3C4433] hover:bg-[#EEEAE1]/50"
                        >
                          <LogOut className="h-4 w-4 mr-2" /> Logout
                        </Button>
                      </>
                    ) : (
                      <Link href="/auth/login">
                        <Button
                          className="bg-transparent border border-[#3C4433]/40 text-[#3C4433] hover:bg-[#EEEAE1]/50 uppercase rounded-md transition-all"
                        >
                          Login
                        </Button>
                      </Link>
                    )}
                  </nav>
                </SheetContent>
              </Sheet>
            </div>

            {/* LOGO */}
            <Link href="/" className="flex items-center transition-all">
              <img src="/black.png" alt="qura logo" className="h-8 w-auto" />
            </Link>

            {/* DESKTOP NAV */}
            <nav className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="text-[11px] font-medium uppercase tracking-widest transition-all"
                  style={{ color: textColor }}
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* RIGHT ICONS (Desktop) */}
            <div className="flex items-center gap-4">
              {user ? (
                <>
                  <Link href="/cart" className="relative">
                    <ShoppingCart
                      className="h-5 w-5 transition-colors"
                      style={{ color: textColor }}
                    />
                    {cartCount > 0 && (
                      <span
                        className={`absolute -top-1.5 -right-1.5 h-4 w-4 rounded-md ${
                          isHome && isHeroVisible
                            ? "bg-[#EEEAE1] text-[#0A0A0A]"
                            : "bg-[#0A0A0A] text-[#EEEAE1]"
                        } text-[10px] flex items-center justify-center font-semibold`}
                      >
                        {cartCount}
                      </span>
                    )}
                  </Link>

                  <Link href="/profile">
                    <User
                      className="h-5 w-5 transition-colors"
                      style={{ color: textColor }}
                    />
                  </Link>

                  {/* Logout Icon only for desktop */}
                  <button
                    onClick={handleLogout}
                    className="hidden md:block hover:opacity-70 transition"
                    style={{ color: textColor }}
                    title="Logout"
                  >
                    <LogOut className="h-5 w-5" />
                  </button>
                </>
              ) : (
                <Link href="/auth/login">
                  <User
                    className="h-5 w-5 transition-colors"
                    style={{ color: textColor }}
                  />
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
