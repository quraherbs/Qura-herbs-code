// "use client"

// import type React from "react"

// import { useState } from "react"
// import { useRouter } from "next/navigation"
// import Link from "next/link"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import { createClient } from "@/lib/supabase/client"
// import { useToast } from "@/hooks/use-toast"

// export function LoginForm() {
//   const [email, setEmail] = useState("")
//   const [password, setPassword] = useState("")
//   const [isLoading, setIsLoading] = useState(false)
//   const router = useRouter()
//   const { toast } = useToast()
//   const supabase = createClient()

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault()
//     setIsLoading(true)

//     try {
//       const { data, error } = await supabase.auth.signInWithPassword({
//         email,
//         password,
//       })

//       if (error) throw error

//       toast({
//         title: "Welcome back!",
//         description: "You have successfully logged in.",
//       })

//       // Check if user is admin
//       if (data.user?.email === "quraherbs@gmail.com") {
//         router.push("/admin")
//       } else {
//         router.push("/")
//       }
//       router.refresh()
//     } catch (error: any) {
//       console.error("[v0] Login error:", error)
//       toast({
//         title: "Login failed",
//         description: error.message || "Invalid email or password",
//         variant: "destructive",
//       })
//     } finally {
//       setIsLoading(false)
//     }
//   }

//   return (
//     <Card className="w-full max-w-md border-[#ccbcaa]/20">
//       <CardHeader>
//         <CardTitle className="text-2xl text-[#000000]">Login</CardTitle>
//         <CardDescription>Enter your credentials to access your account</CardDescription>
//       </CardHeader>
//       <CardContent>
//         <form onSubmit={handleSubmit} className="space-y-4">
//           <div className="space-y-2">
//             <Label htmlFor="email">Email</Label>
//             <Input
//               id="email"
//               type="email"
//               placeholder="you@example.com"
//               value={email}
//               onChange={(e) => setEmail(e.target.value)}
//               required
//             />
//           </div>

//           <div className="space-y-2">
//             <Label htmlFor="password">Password</Label>
//             <Input
//               id="password"
//               type="password"
//               placeholder="••••••••"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               required
//             />
//           </div>

//           <Button
//             type="submit"
//             className="w-full bg-[#000000] text-[#ffffff] hover:bg-[#ccbcaa] hover:text-[#000000]"
//             disabled={isLoading}
//           >
//             {isLoading ? "Logging in..." : "Login"}
//           </Button>

//           <p className="text-center text-sm text-[#000000]/70">
//             Don't have an account?{" "}
//             <Link href="/auth/signup" className="text-[#000000] font-medium hover:text-[#ccbcaa]">
//               Sign up
//             </Link>
//           </p>
//         </form>
//       </CardContent>
//     </Card>
//   )
// }
"use client"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { createClient } from "@/lib/supabase/client"

export function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const router = useRouter()
  const searchParams = useSearchParams()
  const supabase = createClient()

  useEffect(() => {
    if (searchParams.get("verify") === "true") {
      setMessage("Please confirm the mail we have sent to you, then login.")
    }
  }, [searchParams])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setErrorMessage(null)

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      const msg = error.message.toLowerCase()
      if (msg.includes("email not confirmed")) {
        setErrorMessage("Please verify your email before logging in.")
      } else {
        setErrorMessage("Invalid credentials. Please check your email or password.")
      }
      setIsLoading(false)
      return
    }

    if (!data.user) {
      setErrorMessage("User not found. Please sign up first.")
      setIsLoading(false)
      return
    }

    if (data.user.email === "quraherbs@gmail.com") {
      router.push("/admin")
    } else {
      router.push("/")
    }
  }

  return (
    <div className="min-h-screen bg-[#EEEAE1] flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-7xl lg:min-w-[800px]">
        <div className="border border-[#d9d4c8] bg-[#EEEAE1] shadow-[0_4px_20px_rgba(0,0,0,0.08)] rounded-none w-full">
          {/* Header */}
          <div className="space-y-2 text-center pb-6 px-4 pt-6">
            <h1 className="text-2xl sm:text-3xl font-serif font-semibold text-[#0A0A0A]">Login</h1>
            <p className="text-sm text-[#0A0A0A]/70 font-sans">
              Enter your credentials to access your account
            </p>
          </div>

          {/* Content */}
          <div className="px-6 sm:px-12 lg:px-24 pb-10">
            {message && (
              <div className="text-sm text-green-700 font-medium bg-green-50 border border-green-200 rounded-none p-3 mb-4 text-center">
                {message}
              </div>
            )}

            {errorMessage && (
              <div className="text-sm text-red-600 font-medium bg-red-50 border border-red-200 rounded-none p-3 mb-4 text-center">
                {errorMessage}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6 max-w-xl mx-auto">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-[#3C4433] text-[#EEEAE1] hover:bg-[#0A0A0A] hover:text-[#EEEAE1]"
                disabled={isLoading}
              >
                {isLoading ? "Logging in..." : "Login"}
              </Button>

              <p className="text-center text-sm text-[#0A0A0A]/70 font-sans pt-2">
                Don&apos;t have an account?{" "}
                <Link href="/auth/signup" className="text-[#3C4433] font-medium hover:text-[#0A0A0A]">
                  Sign up
                </Link>
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
