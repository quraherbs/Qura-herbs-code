// "use client"

// import { useState } from "react"
// import Image from "next/image"
// import { useRouter } from "next/navigation"
// import { Button } from "@/components/ui/button"
// import { Card, CardContent } from "@/components/ui/card"
// import type { Product } from "@/lib/types"
// import { createClient } from "@/lib/supabase/client"
// import { Minus, Plus, ShoppingCart } from "lucide-react"
// import { useToast } from "@/hooks/use-toast"
// import { motion } from "framer-motion"

// interface ProductDetailClientProps {
//   product: Product
// }

// export function ProductDetailClient({ product }: ProductDetailClientProps) {
//   const [quantity, setQuantity] = useState(1)
//   const [isLoading, setIsLoading] = useState(false)
//   const router = useRouter()
//   const { toast } = useToast()

//   const handleAddToCart = async () => {
//     setIsLoading(true)
//     const supabase = createClient()

//     try {
//       const {
//         data: { user },
//       } = await supabase.auth.getUser()

//       if (!user) {
//         toast({
//           title: "Please login",
//           description: "You need to be logged in to add items to cart",
//           variant: "destructive",
//         })
//         router.push("/auth/login")
//         return
//       }

//       // Check if item already exists in cart
//       const { data: existingItem } = await supabase
//         .from("cart")
//         .select("*")
//         .eq("user_id", user.id)
//         .eq("product_id", product.id)
//         .single()

//       if (existingItem) {
//         // Update quantity
//         const { error } = await supabase
//           .from("cart")
//           .update({ quantity: existingItem.quantity + quantity })
//           .eq("id", existingItem.id)

//         if (error) throw error
//       } else {
//         // Insert new item
//         const { error } = await supabase.from("cart").insert({
//           user_id: user.id,
//           product_id: product.id,
//           quantity,
//         })

//         if (error) throw error
//       }

//       toast({
//         title: "Added to cart",
//         description: `${product.name} has been added to your cart`,
//       })
//     } catch (error) {
//       console.error("[v0] Error adding to cart:", error)
//       toast({
//         title: "Error",
//         description: "Failed to add item to cart",
//         variant: "destructive",
//       })
//     } finally {
//       setIsLoading(false)
//     }
//   }

//   const handleBuyNow = async () => {
//     await handleAddToCart()
//     router.push("/cart")
//   }

//   return (
//     <div className="container mx-auto px-4">
//       <motion.div
//         className="grid grid-cols-1 lg:grid-cols-2 gap-12"
//         initial="hidden"
//         animate="visible"
//         variants={{
//           hidden: { opacity: 0 },
//           visible: {
//             opacity: 1,
//             transition: {
//               staggerChildren: 0.2,
//             },
//           },
//         }}
//       >
//         <motion.div
//           className="aspect-square relative bg-[#f0e9e2] rounded-lg overflow-hidden"
//           variants={{
//             hidden: { opacity: 0, x: -20 },
//             visible: { opacity: 1, x: 0 },
//           }}
//           transition={{ duration: 0.6 }}
//         >
//           <Image
//             src={product.image_url || "/placeholder.svg?height=600&width=600"}
//             alt={product.name}
//             fill
//             className="object-cover"
//             priority
//           />
//         </motion.div>

//         <motion.div
//           className="flex flex-col gap-6"
//           variants={{
//             hidden: { opacity: 0, x: 20 },
//             visible: { opacity: 1, x: 0 },
//           }}
//           transition={{ duration: 0.6 }}
//         >
//           <div>
//             <h1 className="text-3xl md:text-4xl font-bold text-[#000000] mb-2 font-serif">{product.name}</h1>
//             {product.category && <p className="text-[#ccbcaa] font-medium">{product.category}</p>}
//           </div>

//           <div className="text-3xl font-bold text-[#000000]">₹{product.price}</div>

//           <p className="text-[#000000]/70 leading-relaxed">{product.description}</p>

//           <Card className="border-[#ccbcaa]/20">
//             <CardContent className="p-4">
//               <div className="flex items-center justify-between">
//                 <span className="text-sm font-medium text-[#000000]">
//                   Stock: {product.stock > 0 ? `${product.stock} available` : "Out of stock"}
//                 </span>
//               </div>
//             </CardContent>
//           </Card>

//           <div className="flex items-center gap-4">
//             <span className="text-sm font-medium text-[#000000]">Quantity:</span>
//             <div className="flex items-center gap-2">
//               <Button
//                 variant="outline"
//                 size="icon"
//                 onClick={() => setQuantity(Math.max(1, quantity - 1))}
//                 disabled={quantity <= 1}
//                 className="border-[#ccbcaa]"
//               >
//                 <Minus className="h-4 w-4" />
//               </Button>
//               <span className="w-12 text-center font-medium">{quantity}</span>
//               <Button
//                 variant="outline"
//                 size="icon"
//                 onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
//                 disabled={quantity >= product.stock}
//                 className="border-[#ccbcaa]"
//               >
//                 <Plus className="h-4 w-4" />
//               </Button>
//             </div>
//           </div>

//           <div className="flex flex-col sm:flex-row gap-4">
//             <Button
//               size="lg"
//               onClick={handleAddToCart}
//               disabled={isLoading || product.stock === 0}
//               className="flex-1 bg-[#ffffff] text-[#000000] border-2 border-[#000000] hover:bg-[#f0e9e2]"
//             >
//               <ShoppingCart className="mr-2 h-5 w-5" />
//               Add to Cart
//             </Button>
//             <Button
//               size="lg"
//               onClick={handleBuyNow}
//               disabled={isLoading || product.stock === 0}
//               className="flex-1 bg-[#000000] text-[#ffffff] hover:bg-[#ccbcaa] hover:text-[#000000]"
//             >
//               Buy Now
//             </Button>
//           </div>

//           {product.stock === 0 && <p className="text-sm text-destructive">This product is currently out of stock</p>}
//         </motion.div>
//       </motion.div>
//     </div>
//   )
// }
"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import type { Product } from "@/lib/types"
import { createClient } from "@/lib/supabase/client"
import { Minus, Plus, ShoppingCart } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { motion } from "framer-motion"

interface ProductDetailClientProps {
  product: Product
}

export function ProductDetailClient({ product }: ProductDetailClientProps) {
  const [quantity, setQuantity] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const handleAddToCart = async () => {
    setIsLoading(true)
    const supabase = createClient()

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        toast({
          title: "Please login",
          description: "You need to be logged in to add items to cart",
          variant: "destructive",
        })
        router.push("/auth/login")
        return
      }

      const { data: existingItem } = await supabase
        .from("cart")
        .select("*")
        .eq("user_id", user.id)
        .eq("product_id", product.id)
        .single()

      if (existingItem) {
        const { error } = await supabase
          .from("cart")
          .update({ quantity: existingItem.quantity + quantity })
          .eq("id", existingItem.id)
        if (error) throw error
      } else {
        const { error } = await supabase.from("cart").insert({
          user_id: user.id,
          product_id: product.id,
          quantity,
        })
        if (error) throw error
      }

      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart`,
      })
    } catch (error) {
      console.error("[v0] Error adding to cart:", error)
      toast({
        title: "Error",
        description: "Failed to add item to cart",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleBuyNow = async () => {
    await handleAddToCart()
    router.push("/cart")
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <motion.div
        className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start"
        initial="hidden"
        animate="visible"
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: { staggerChildren: 0.2 },
          },
        }}
      >
        {/* Product Image */}
        <motion.div
          className="relative bg-[#EEEAE1] overflow-hidden border border-[#d9d4c8] shadow-sm rounded-none h-[360px] md:h-[420px] lg:h-[460px]"
          variants={{
            hidden: { opacity: 0, x: -20 },
            visible: { opacity: 1, x: 0 },
          }}
          transition={{ duration: 0.6 }}
        >
          <Image
            src={product.image_url || "/placeholder.svg?height=600&width=600"}
            alt={product.name}
            fill
            className="object-cover w-full h-full"
            priority
          />
        </motion.div>

        {/* Product Details */}
        <motion.div
          className="flex flex-col gap-6 text-[#0A0A0A]"
          variants={{
            hidden: { opacity: 0, x: 20 },
            visible: { opacity: 1, x: 0 },
          }}
          transition={{ duration: 0.6 }}
        >
          <div className="space-y-1">
            <h1 className="text-3xl md:text-4xl font-serif font-bold mb-2">
              {product.name}
            </h1>
            {product.category && (
              <p className="text-sm font-medium text-[#3C4433]/80">
                {product.category}
              </p>
            )}
          </div>

          {/* Price + Stock Badge */}
          <div className="flex items-center gap-4 flex-wrap">
            <div className="text-3xl font-bold text-[#3C4433]">
              ₹{product.price}
            </div>
            {product.stock > 0 ? (
              <span className="text-xs font-semibold bg-[#3C4433] text-[#EEEAE1] px-3 py-1 rounded-none uppercase tracking-wide">
                {product.stock} Available
              </span>
            ) : (
              <span className="text-xs font-semibold bg-red-600 text-white px-3 py-1 rounded-none uppercase tracking-wide">
                Out of Stock
              </span>
            )}
          </div>

          <p className="text-sm text-[#0A0A0A]/80 leading-relaxed">
            {product.description}
          </p>

          {/* Quantity Selector */}
            <div>
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium">Quantity:</span>
              <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
                className="border border-[#3C4433]/30 text-[#0A0A0A] bg-transparent hover:bg-[#EEEAE1]/60 rounded-none cursor-pointer"
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="w-10 text-center font-medium">{quantity}</span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                disabled={quantity >= product.stock}
                className="border border-[#3C4433]/30 text-[#0A0A0A] bg-transparent hover:bg-[#EEEAE1]/60 rounded-none cursor-pointer"
              >
                <Plus className="h-4 w-4" />
              </Button>
              </div>
            </div>

            {/* Shipping + Total */}
            <div className="mt-3 space-y-1">
              <div className="flex items-center justify-between text-sm text-[#0A0A0A]/80">
              <span>Shipping</span>
              <span className="font-medium">₹80</span>
              </div>

              <div className="flex items-center justify-between text-base md:text-lg font-semibold text-[#0A0A0A]">
              <span>Total</span>
              <span>
                ₹{Number(product.price) * quantity + 80}
              </span>
              </div>
            </div>
            </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 w-full">
            <Button
              size="lg"
              onClick={handleAddToCart}
              disabled={isLoading || product.stock === 0}
              className="flex items-center justify-center border border-[#3C4433] bg-transparent text-[#0A0A0A] hover:bg-[#EEEAE1]/70 rounded-none cursor-pointer transition-all duration-300 w-full"
            >
              <ShoppingCart className="mr-2 h-5 w-5" />
              Add to Cart
            </Button>

            <Button
              size="lg"
              onClick={handleBuyNow}
              disabled={isLoading || product.stock === 0}
              className="bg-[#3C4433] text-[#EEEAE1] hover:bg-[#0A0A0A] hover:text-[#EEEAE1] rounded-none cursor-pointer transition-all duration-300 w-full"
            >
              Buy Now
            </Button>
          </div>

          {product.stock === 0 && (
            <p className="text-sm text-red-600 mt-2">
              This product is currently out of stock
            </p>
          )}
        </motion.div>
      </motion.div>
    </div>
  )
}
