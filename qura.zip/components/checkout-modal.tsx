// "use client"

// import type React from "react"

// import { useState } from "react"
// import { useRouter } from "next/navigation"
// import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { createClient } from "@/lib/supabase/client"
// import type { CartItem, Profile } from "@/lib/types"
// import { useToast } from "@/hooks/use-toast"

// interface CheckoutModalProps {
//   open: boolean
//   onOpenChange: (open: boolean) => void
//   cartItems: CartItem[]
//   subtotal: number
//   shippingCharge: number
//   total: number
//   userProfile: Profile | null
// }

// export function CheckoutModal({
//   open,
//   onOpenChange,
//   cartItems,
//   subtotal,
//   shippingCharge,
//   total,
//   userProfile,
// }: CheckoutModalProps) {
//   const [isLoading, setIsLoading] = useState(false)
//   const [formData, setFormData] = useState({
//     fullName: userProfile?.full_name || "",
//     email: userProfile?.email || "",
//     phone: userProfile?.phone || "",
//     address: userProfile?.address || "",
//     city: userProfile?.city || "",
//     state: userProfile?.state || "",
//     pincode: userProfile?.pincode || "",
//   })
//   const router = useRouter()
//   const { toast } = useToast()
//   const supabase = createClient()

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault()
//     setIsLoading(true)

//     try {
//       const {
//         data: { user },
//       } = await supabase.auth.getUser()
//       if (!user) throw new Error("Not authenticated")

//       // Create order
//       const { data: order, error: orderError } = await supabase
//         .from("orders")
//         .insert({
//           user_id: user.id,
//           full_name: formData.fullName,
//           email: formData.email,
//           phone: formData.phone,
//           address: formData.address,
//           city: formData.city,
//           state: formData.state,
//           pincode: formData.pincode,
//           subtotal,
//           shipping_charge: shippingCharge,
//           total,
//           status: "pending",
//         })
//         .select()
//         .single()

//       if (orderError) throw orderError

//       // Create order items
//       const orderItems = cartItems.map((item) => ({
//         order_id: order.id,
//         product_id: item.product_id,
//         product_name: item.products?.name || "",
//         product_price: item.products?.price || 0,
//         quantity: item.quantity,
//       }))

//       const { error: itemsError } = await supabase.from("order_items").insert(orderItems)

//       if (itemsError) throw itemsError

//       // Send order confirmation email
//       await fetch("/api/send-order-email", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           orderId: order.id,
//           customerEmail: formData.email,
//           customerName: formData.fullName,
//           orderItems: cartItems.map((item) => ({
//             name: item.products?.name,
//             quantity: item.quantity,
//             price: item.products?.price,
//           })),
//           subtotal,
//           shippingCharge,
//           total,
//         }),
//       })

//       // Clear cart
//       const { error: clearError } = await supabase.from("cart").delete().eq("user_id", user.id)

//       if (clearError) throw clearError

//       toast({
//         title: "Order placed successfully!",
//         description: "You will receive a confirmation email shortly.",
//       })

//       onOpenChange(false)
//       router.push("/orders")
//     } catch (error) {
//       console.error("[v0] Error placing order:", error)
//       toast({
//         title: "Error",
//         description: "Failed to place order. Please try again.",
//         variant: "destructive",
//       })
//     } finally {
//       setIsLoading(false)
//     }
//   }

//   return (
//     <Dialog open={open} onOpenChange={onOpenChange}>
//       <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
//         <DialogHeader>
//           <DialogTitle className="text-2xl">Checkout</DialogTitle>
//           <DialogDescription>Enter your delivery details to complete your order</DialogDescription>
//         </DialogHeader>

//         <form onSubmit={handleSubmit} className="space-y-4">
//           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//             <div className="space-y-2">
//               <Label htmlFor="fullName">Full Name *</Label>
//               <Input
//                 id="fullName"
//                 required
//                 value={formData.fullName}
//                 onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
//               />
//             </div>

//             <div className="space-y-2">
//               <Label htmlFor="email">Email *</Label>
//               <Input
//                 id="email"
//                 type="email"
//                 required
//                 value={formData.email}
//                 onChange={(e) => setFormData({ ...formData, email: e.target.value })}
//               />
//             </div>

//             <div className="space-y-2">
//               <Label htmlFor="phone">Phone *</Label>
//               <Input
//                 id="phone"
//                 type="tel"
//                 required
//                 value={formData.phone}
//                 onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
//               />
//             </div>

//             <div className="space-y-2 md:col-span-2">
//               <Label htmlFor="address">Address *</Label>
//               <Input
//                 id="address"
//                 required
//                 value={formData.address}
//                 onChange={(e) => setFormData({ ...formData, address: e.target.value })}
//               />
//             </div>

//             <div className="space-y-2">
//               <Label htmlFor="city">City *</Label>
//               <Input
//                 id="city"
//                 required
//                 value={formData.city}
//                 onChange={(e) => setFormData({ ...formData, city: e.target.value })}
//               />
//             </div>

//             <div className="space-y-2">
//               <Label htmlFor="state">State *</Label>
//               <Input
//                 id="state"
//                 required
//                 value={formData.state}
//                 onChange={(e) => setFormData({ ...formData, state: e.target.value })}
//               />
//             </div>

//             <div className="space-y-2">
//               <Label htmlFor="pincode">Pincode *</Label>
//               <Input
//                 id="pincode"
//                 required
//                 value={formData.pincode}
//                 onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
//               />
//             </div>
//           </div>

//           <div className="border-t border-[#ccbcaa]/20 pt-4 mt-6">
//             <div className="space-y-2 mb-4">
//               <div className="flex justify-between text-[#000000]/70">
//                 <span>Subtotal</span>
//                 <span>₹{subtotal.toFixed(2)}</span>
//               </div>
//               <div className="flex justify-between text-[#000000]/70">
//                 <span>Shipping</span>
//                 <span>₹{shippingCharge.toFixed(2)}</span>
//               </div>
//               <div className="flex justify-between text-lg font-bold text-[#000000]">
//                 <span>Total</span>
//                 <span>₹{total.toFixed(2)}</span>
//               </div>
//             </div>

//             <Button
//               type="submit"
//               className="w-full bg-[#000000] text-[#ffffff] hover:bg-[#ccbcaa] hover:text-[#000000]"
//               disabled={isLoading}
//             >
//               {isLoading ? "Placing Order..." : "Place Order"}
//             </Button>
//           </div>
//         </form>
//       </DialogContent>
//     </Dialog>
//   )
// }
"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { createClient } from "@/lib/supabase/client"
import type { CartItem, Profile } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"

interface CheckoutModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  cartItems: CartItem[]
  subtotal: number
  shippingCharge: number
  total: number
  userProfile: Profile | null
}

export function CheckoutModal({
  open,
  onOpenChange,
  cartItems,
  subtotal,
  shippingCharge,
  total,
  userProfile,
}: CheckoutModalProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    fullName: userProfile?.full_name || "",
    email: userProfile?.email || "",
    phone: userProfile?.phone || "",
    address: userProfile?.address || "",
    city: userProfile?.city || "",
    state: userProfile?.state || "",
    pincode: userProfile?.pincode || "",
  })
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Not authenticated")

      const { data: order, error: orderError } = await supabase
        .from("orders")
        .insert({
          user_id: user.id,
          full_name: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          address: formData.address,
          city: formData.city,
          state: formData.state,
          pincode: formData.pincode,
          subtotal,
          shipping_charge: shippingCharge,
          total,
          status: "pending",
        })
        .select()
        .single()

      if (orderError) throw orderError

      const orderItems = cartItems.map((item) => ({
        order_id: order.id,
        product_id: item.product_id,
        product_name: item.products?.name || "",
        product_price: item.products?.price || 0,
        quantity: item.quantity,
      }))

      const { error: itemsError } = await supabase.from("order_items").insert(orderItems)
      if (itemsError) throw itemsError

      await fetch("/api/send-order-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId: order.id,
          customerEmail: formData.email,
          customerName: formData.fullName,
          orderItems: cartItems.map((item) => ({
            name: item.products?.name,
            quantity: item.quantity,
            price: item.products?.price,
          })),
          subtotal,
          shippingCharge,
          total,
        }),
      })

      const { error: clearError } = await supabase.from("cart").delete().eq("user_id", user.id)
      if (clearError) throw clearError

      toast({
        title: "Order placed successfully!",
        description: "You will receive a confirmation email shortly.",
      })

      onOpenChange(false)
      router.push("/orders")
    } catch (error) {
      console.error("[v0] Error placing order:", error)
      toast({
        title: "Error",
        description: "Failed to place order. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-[#EEEAE1] border border-[#d9d4c8] rounded-none shadow-[0_4px_20px_rgba(0,0,0,0.08)]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-serif text-[#0A0A0A]">
            Checkout
          </DialogTitle>
          <DialogDescription className="text-sm text-[#0A0A0A]/70">
            Enter your delivery details to complete your order
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fullName" className="text-[#0A0A0A]/80 text-sm">
                Full Name *
              </Label>
              <Input
                id="fullName"
                required
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                className="border border-[#3C4433]/30 bg-[#ffffff] text-[#0A0A0A] rounded-none"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-[#0A0A0A]/80 text-sm">
                Email *
              </Label>
              <Input
                id="email"
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="border border-[#3C4433]/30 bg-[#ffffff] text-[#0A0A0A] rounded-none"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone" className="text-[#0A0A0A]/80 text-sm">
                Phone *
              </Label>
              <Input
                id="phone"
                type="tel"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="border border-[#3C4433]/30 bg-[#ffffff] text-[#0A0A0A] rounded-none"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="address" className="text-[#0A0A0A]/80 text-sm">
                Address *
              </Label>
              <Input
                id="address"
                required
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="border border-[#3C4433]/30 bg-[#ffffff] text-[#0A0A0A] rounded-none"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="city" className="text-[#0A0A0A]/80 text-sm">
                City *
              </Label>
              <Input
                id="city"
                required
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="border border-[#3C4433]/30 bg-[#ffffff] text-[#0A0A0A] rounded-none"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="state" className="text-[#0A0A0A]/80 text-sm">
                State *
              </Label>
              <Input
                id="state"
                required
                value={formData.state}
                onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                className="border border-[#3C4433]/30 bg-[#ffffff] text-[#0A0A0A] rounded-none"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="pincode" className="text-[#0A0A0A]/80 text-sm">
                Pincode *
              </Label>
              <Input
                id="pincode"
                required
                value={formData.pincode}
                onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                className="border border-[#3C4433]/30 bg-[#ffffff] text-[#0A0A0A] rounded-none"
              />
            </div>
          </div>

          <div className="border-t border-[#3C4433]/20 pt-4 mt-6">
            <div className="space-y-2 mb-4 text-sm text-[#0A0A0A]/80">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping</span>
                <span>₹{shippingCharge.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-base font-medium text-[#0A0A0A]">
                <span>Total</span>
                <span>₹{total.toFixed(2)}</span>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-[#3C4433] text-[#EEEAE1] hover:bg-[#0A0A0A] hover:text-[#EEEAE1] rounded-none transition-colors duration-300"
              disabled={isLoading}
            >
              {isLoading ? "Placing Order..." : "Place Order"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
