// "use client"

// import type React from "react"

// import { useState } from "react"
// import { useRouter } from "next/navigation"
// import Link from "next/link"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import { createClient } from "@/lib/supabase/client"
// import { useToast } from "@/hooks/use-toast"

// export function SignupForm() {
//   const [formData, setFormData] = useState({
//     fullName: "",
//     email: "",
//     password: "",
//     confirmPassword: "",
//   })
//   const [isLoading, setIsLoading] = useState(false)
//   const router = useRouter()
//   const { toast } = useToast()
//   const supabase = createClient()

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault()

//     if (formData.password !== formData.confirmPassword) {
//       toast({
//         title: "Passwords don't match",
//         description: "Please make sure your passwords match",
//         variant: "destructive",
//       })
//       return
//     }

//     if (formData.password.length < 6) {
//       toast({
//         title: "Password too short",
//         description: "Password must be at least 6 characters",
//         variant: "destructive",
//       })
//       return
//     }

//     setIsLoading(true)

//     try {
//       const { data, error } = await supabase.auth.signUp({
//         email: formData.email,
//         password: formData.password,
//         options: {
//           emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || window.location.origin,
//           data: {
//             full_name: formData.fullName,
//           },
//         },
//       })

//       if (error) throw error

//       // Create profile
//       if (data.user) {
//         const { error: profileError } = await supabase.from("profiles").insert({
//           id: data.user.id,
//           email: formData.email,
//           full_name: formData.fullName,
//         })

//         if (profileError) {
//           console.error("[v0] Profile creation error:", profileError)
//         }
//       }

//       toast({
//         title: "Account created!",
//         description: "Please check your email to verify your account.",
//       })

//       router.push("/auth/login")
//     } catch (error: any) {
//       console.error("[v0] Signup error:", error)
//       toast({
//         title: "Signup failed",
//         description: error.message || "Failed to create account",
//         variant: "destructive",
//       })
//     } finally {
//       setIsLoading(false)
//     }
//   }

//   return (
//     <Card className="w-full max-w-md border-[#ccbcaa]/20">
//       <CardHeader>
//         <CardTitle className="text-2xl text-[#000000]">Create Account</CardTitle>
//         <CardDescription>Sign up to start shopping with Qura Herbs</CardDescription>
//       </CardHeader>
//       <CardContent>
//         <form onSubmit={handleSubmit} className="space-y-4">
//           <div className="space-y-2">
//             <Label htmlFor="fullName">Full Name</Label>
//             <Input
//               id="fullName"
//               type="text"
//               placeholder="John Doe"
//               value={formData.fullName}
//               onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
//               required
//             />
//           </div>

//           <div className="space-y-2">
//             <Label htmlFor="email">Email</Label>
//             <Input
//               id="email"
//               type="email"
//               placeholder="you@example.com"
//               value={formData.email}
//               onChange={(e) => setFormData({ ...formData, email: e.target.value })}
//               required
//             />
//           </div>

//           <div className="space-y-2">
//             <Label htmlFor="password">Password</Label>
//             <Input
//               id="password"
//               type="password"
//               placeholder="••••••••"
//               value={formData.password}
//               onChange={(e) => setFormData({ ...formData, password: e.target.value })}
//               required
//             />
//           </div>

//           <div className="space-y-2">
//             <Label htmlFor="confirmPassword">Confirm Password</Label>
//             <Input
//               id="confirmPassword"
//               type="password"
//               placeholder="••••••••"
//               value={formData.confirmPassword}
//               onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
//               required
//             />
//           </div>

//           <Button
//             type="submit"
//             className="w-full bg-[#000000] text-[#ffffff] hover:bg-[#ccbcaa] hover:text-[#000000]"
//             disabled={isLoading}
//           >
//             {isLoading ? "Creating account..." : "Sign Up"}
//           </Button>

//           <p className="text-center text-sm text-[#000000]/70">
//             Already have an account?{" "}
//             <Link href="/auth/login" className="text-[#000000] font-medium hover:text-[#ccbcaa]">
//               Login
//             </Link>
//           </p>
//         </form>
//       </CardContent>
//     </Card>
//   )
// }
"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"

export function SignupForm() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const supabase = createClient()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setErrorMessage(null)

    if (formData.password !== formData.confirmPassword) {
      setErrorMessage("Passwords do not match. Please recheck and try again.")
      return
    }

    if (formData.password.length < 6) {
      setErrorMessage("Password must be at least 6 characters long.")
      return
    }

    setIsLoading(true)

    try {
      const { error } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          emailRedirectTo:
            process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || window.location.origin,
          data: { full_name: formData.fullName },
        },
      })

      if (error) throw error

      // ✅ Redirect to login page with message flag
      router.push("/auth/login?verify=true")
    } catch (error: any) {
      console.error("[Signup Error]", error)
      setErrorMessage(error.message || "Failed to create account. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#EEEAE1] flex flex-col items-center justify-center px-4 pt-28 pb-16">
      <Card className="w-full max-w-3xl border border-[#d9d4c8] bg-[#EEEAE1] shadow-[0_4px_20px_rgba(0,0,0,0.08)] rounded-none">
        <CardHeader className="pb-8 text-center">
          <CardTitle className="text-3xl font-serif font-semibold text-[#0A0A0A]">
            Create Account
          </CardTitle>
          <CardDescription className="text-sm text-[#0A0A0A]/70 font-sans mt-2">
            Sign up to start shopping with Qura Herbs
          </CardDescription>
        </CardHeader>

        <CardContent className="px-20 pb-14">
          {errorMessage && (
            <div className="text-sm text-red-600 font-medium bg-red-50 border border-red-200 rounded-none p-3 mb-4 text-center">
              {errorMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Full Name */}
            <div className="space-y-2">
              <Label htmlFor="fullName" className="text-[#0A0A0A]/80 text-sm font-sans">
                Full Name
              </Label>
              <Input
                id="fullName"
                type="text"
                placeholder="John Doe"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                required
                className="border border-[#3C4433]/30 bg-white text-[#0A0A0A] rounded-none focus:ring-0 focus:border-[#3C4433]"
              />
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email" className="text-[#0A0A0A]/80 text-sm font-sans">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="border border-[#3C4433]/30 bg-white text-[#0A0A0A] rounded-none focus:ring-0 focus:border-[#3C4433]"
              />
            </div>

            {/* Password */}
            <div className="space-y-2">
              <Label htmlFor="password" className="text-[#0A0A0A]/80 text-sm font-sans">
                Password
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required
                  className="border border-[#3C4433]/30 bg-white text-[#0A0A0A] pr-10 rounded-none focus:ring-0 focus:border-[#3C4433]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#3C4433]/70 hover:text-[#0A0A0A] cursor-pointer"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-[#0A0A0A]/80 text-sm font-sans">
                Confirm Password
              </Label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={formData.confirmPassword}
                  onChange={(e) =>
                    setFormData({ ...formData, confirmPassword: e.target.value })
                  }
                  required
                  className="border border-[#3C4433]/30 bg-white text-[#0A0A0A] pr-10 rounded-none focus:ring-0 focus:border-[#3C4433]"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#3C4433]/70 hover:text-[#0A0A0A] cursor-pointer"
                >
                  {showConfirmPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full bg-[#3C4433] text-[#EEEAE1] hover:bg-[#0A0A0A] hover:text-[#EEEAE1] rounded-none font-medium cursor-pointer"
              disabled={isLoading}
            >
              {isLoading ? "Creating account..." : "Sign Up"}
            </Button>

            {/* Login Link */}
            <p className="text-center text-sm text-[#0A0A0A]/70 font-sans">
              Already have an account?{" "}
              <Link
                href="/auth/login"
                className="text-[#3C4433] font-medium hover:text-[#0A0A0A] cursor-pointer"
              >
                Login
              </Link>
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
