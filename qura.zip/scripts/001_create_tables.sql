-- Create profiles table (extends auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  phone text,
  address text,
  city text,
  state text,
  pincode text,
  is_admin boolean default false,
  created_at timestamp with time zone default now()
);

alter table public.profiles enable row level security;

-- Profiles policies
create policy "profiles_select_own"
  on public.profiles for select
  using (auth.uid() = id or is_admin = true);

create policy "profiles_insert_own"
  on public.profiles for insert
  with check (auth.uid() = id);

create policy "profiles_update_own"
  on public.profiles for update
  using (auth.uid() = id);

-- Create products table
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price decimal(10, 2) not null,
  image_url text,
  category text,
  stock integer default 0,
  is_active boolean default true,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

alter table public.products enable row level security;

-- Products policies (public read, admin write)
create policy "products_select_all"
  on public.products for select
  using (is_active = true);

create policy "products_insert_admin"
  on public.products for insert
  with check (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and is_admin = true
    )
  );

create policy "products_update_admin"
  on public.products for update
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and is_admin = true
    )
  );

create policy "products_delete_admin"
  on public.products for delete
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and is_admin = true
    )
  );

-- Create cart table
create table if not exists public.cart (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  product_id uuid references public.products(id) on delete cascade,
  quantity integer not null default 1,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  unique(user_id, product_id)
);

alter table public.cart enable row level security;

-- Cart policies
create policy "cart_select_own"
  on public.cart for select
  using (auth.uid() = user_id);

create policy "cart_insert_own"
  on public.cart for insert
  with check (auth.uid() = user_id);

create policy "cart_update_own"
  on public.cart for update
  using (auth.uid() = user_id);

create policy "cart_delete_own"
  on public.cart for delete
  using (auth.uid() = user_id);

-- Create orders table
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null,
  phone text not null,
  address text not null,
  city text not null,
  state text not null,
  pincode text not null,
  subtotal decimal(10, 2) not null,
  shipping_charge decimal(10, 2) default 80.00,
  total decimal(10, 2) not null,
  status text default 'pending',
  created_at timestamp with time zone default now()
);

alter table public.orders enable row level security;

-- Orders policies
create policy "orders_select_own"
  on public.orders for select
  using (auth.uid() = user_id or exists (
    select 1 from public.profiles
    where id = auth.uid() and is_admin = true
  ));

create policy "orders_insert_own"
  on public.orders for insert
  with check (auth.uid() = user_id);

create policy "orders_update_admin"
  on public.orders for update
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and is_admin = true
    )
  );

-- Create order_items table
create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references public.orders(id) on delete cascade,
  product_id uuid references public.products(id),
  product_name text not null,
  product_price decimal(10, 2) not null,
  quantity integer not null,
  created_at timestamp with time zone default now()
);

alter table public.order_items enable row level security;

-- Order items policies
create policy "order_items_select_own"
  on public.order_items for select
  using (
    exists (
      select 1 from public.orders
      where id = order_id and (user_id = auth.uid() or exists (
        select 1 from public.profiles
        where id = auth.uid() and is_admin = true
      ))
    )
  );

create policy "order_items_insert_own"
  on public.order_items for insert
  with check (
    exists (
      select 1 from public.orders
      where id = order_id and user_id = auth.uid()
    )
  );
