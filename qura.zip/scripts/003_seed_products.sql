-- Insert sample products for Qura Herbs
insert into public.products (name, description, price, image_url, category, stock, is_active) values
  ('GLOW RADIANT NIGHT CREAM', 'A perfect nighttime skincare essential for all skin types, designed to brighten, hydrate, and repair your skin while you sleep.', 299.00, '/placeholder.svg?height=400&width=400', 'Face Care', 50, true),
  ('Turmeric Glow Cream', 'Brightening cream with turmeric and saffron. Reduces dark spots and enhances natural glow.', 499.00, '/placeholder.svg?height=400&width=400', 'Face Care', 40, true),
  ('Rose Water Toner', 'Pure rose water toner for refreshing and balancing skin pH. Suitable for all skin types.', 199.00, '/placeholder.svg?height=400&width=400', 'Face Care', 60, true),
  ('Aloe Vera Gel', 'Pure aloe vera gel for soothing and hydrating skin. Perfect for sunburn relief and daily moisturizing.', 249.00, '/placeholder.svg?height=400&width=400', 'Body Care', 45, true),
  ('Sandalwood Soap', 'Handmade sandalwood soap with natural oils. Cleanses and nourishes skin with a calming fragrance.', 149.00, '/placeholder.svg?height=400&width=400', 'Body Care', 80, true),
  ('Hibiscus Hair Oil', 'Nourishing hair oil with hibiscus and coconut. Promotes hair growth and adds natural shine.', 399.00, '/placeholder.svg?height=400&width=400', 'Hair Care', 35, true);
