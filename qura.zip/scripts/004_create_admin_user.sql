create or replace function public.check_admin_email()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.email = 'quraherbs@gmail.com' then
    new.is_admin := true;
  end if;
  return new;
end;
$$;

drop trigger if exists set_admin_on_profile_insert on public.profiles;

create trigger set_admin_on_profile_insert
  before insert on public.profiles
  for each row
  execute function public.check_admin_email();
